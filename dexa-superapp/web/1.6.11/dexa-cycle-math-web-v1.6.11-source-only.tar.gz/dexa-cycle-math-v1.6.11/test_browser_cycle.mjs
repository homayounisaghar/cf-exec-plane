import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {spawn} from 'node:child_process';
import {setTimeout as sleep} from 'node:timers/promises';
const require=createRequire(import.meta.url);
const puppeteer=require('/home/cfserver/.npm/_npx/bbe7c48ef48a4873/node_modules/puppeteer');
const ROOT='/home/cfserver/dexa-superapp-build/cycle-math-v1611-candidate/web';
const URL='http://127.0.0.1:4595/';
const runCount = [0,0];

function mockHTML(slot,answerMode) {
 const proposed=answerMode==='malformed'?'مثلاً سؤال: ۷ × ۶ چند می‌شود؟':'۷ × ۶ = ؟';
 const result=answerMode==='wrong'?'۴۱':'۴۲';
 return `<!doctype html><html lang="fa"><head><meta charset="utf-8"><title>ChatGPT fixture</title>
 <style>body{font-family:Arial;padding:12px}button,textarea,[contenteditable]{padding:8px;margin:4px;display:inline-block}
 [contenteditable]{border:1px solid #bbb;min-width:180px;min-height:24px;white-space:pre-wrap}
 </style></head><body><button id="model" aria-label="Select ChatGPT model" aria-expanded="false">Instant</button>
 <div id="menu"></div><main><div id="thread"></div><div id="prompt-textarea" contenteditable="true" role="textbox" aria-label="Ask ChatGPT"></div>
 <button type="submit" data-testid="send-button" id="send" disabled>Send</button></main>
 <script>
  const USER_REPLY=${JSON.stringify(slot===0?proposed:result)};
  const model=document.getElementById('model'),menu=document.getElementById('menu');
  model.addEventListener('click',()=>{
   if(model.getAttribute('aria-expanded')==='true')return;
   model.setAttribute('aria-expanded','true');
   menu.innerHTML='<div role="menu"><div role="group"><div role="menuitem" aria-label="Power" data-reasoning-slider="yes" tabindex="0"><span role="slider" aria-valuenow="0" aria-valuemin="0" aria-valuemax="4"></span></div><div role="status">Instant, 1 of 5.</div></div></div>';
   menu.querySelector('[role="menuitem"]').addEventListener('keydown',e=>{
    if(e.key==='Escape'){model.setAttribute('aria-expanded','false');menu.replaceChildren();}
   });
  });
  const input=document.getElementById('prompt-textarea'),send=document.getElementById('send');
  const update=()=>{const shouldDisable=!input.innerText.trim();if(send.disabled!==shouldDisable)send.disabled=shouldDisable;};
  input.addEventListener('input',update);
  const observer=new MutationObserver(()=>update());observer.observe(input,{childList:true,subtree:true,characterData:true});
  window.__mock={sendCount:0,lastPrompt:''};
  send.addEventListener('click',()=>{
   if(send.disabled)return;
   const text=input.innerText.trim();
   if(!text)return;
   window.__mock.sendCount++;window.__mock.lastPrompt=text;
   history.pushState({},'', '/c/fixture-'+${slot}+'-'+window.__mock.sendCount);
   const user=document.createElement('div');user.setAttribute('data-message-author-role','user');user.textContent=text;
   document.getElementById('thread').appendChild(user);
   input.textContent='';update();
   setTimeout(()=>{
    const a=document.createElement('div');a.setAttribute('data-message-author-role','assistant');a.textContent=USER_REPLY;
    document.getElementById('thread').appendChild(a);
   },250);
  });
 </script></body></html>`;
}

const server=spawn('node',[ROOT+'/server.mjs'],{env:{...process.env,PORT:'4595',DEXA_BIND_HOST:'127.0.0.1'},stdio:['ignore','pipe','pipe']});
let serverErrors='';server.stderr.on('data',b=>{serverErrors+=b});
async function ready(){for(let i=0;i<80;i++){try{const r=await fetch(URL+'api/health');if(r.ok)return;}catch{}await sleep(120)}throw Error('STAGING_SERVER_NOT_READY:'+serverErrors)}
async function main() {
 await ready();
 const browser=await puppeteer.launch({executablePath:'/snap/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  async function scenario(name,answerMode,expectedStage,expectedSends){
   const pages=await Promise.all([browser.newPage(),browser.newPage()]);
   for(let slot=0;slot<2;slot++){
    const p=pages[slot];
    await p.setRequestInterception(true);
    p.on('request',req=>{
      if(req.isNavigationRequest()&&req.url().startsWith('https://chatgpt.com/'))
       req.respond({status:200,contentType:'text/html; charset=utf-8',body:mockHTML(slot,answerMode)}).catch(()=>{});
      else req.abort().catch(()=>{});
    });
    await p.goto('https://chatgpt.com/',{waitUntil:'domcontentloaded'});
   }
   const dash=await browser.newPage();
   const transfers=new Map();
   const hostState={count:2,remoteArmed:false,nativeRemoteService:true,nativeRemoteTransport:true,
      showingDashboard:true,browsers:[{slot:0,url:'https://chatgpt.com/',visible:false},
      {slot:1,url:'https://chatgpt.com/',visible:false}]};
   await dash.exposeFunction('__nativeSend',async m=>{
    const reply={ok:true,state:hostState};
    try{
     if(m.op==='status')reply.result=hostState;
     else if(m.op==='remote-native-setup')reply.result={saved:true};
     else if(m.op==='eval-begin'){
      assert.equal(typeof m.runId,'string');
      transfers.set(m.runId,{slot:m.slot,src:'',url:pages[m.slot].url()});
     }else if(m.op==='eval-part'){
      const t=transfers.get(m.runId);assert.ok(t,'TRANSFER_NOT_FOUND');t.src+=m.part;
     }else if(m.op==='eval-finish'){
      const t=transfers.get(m.runId);assert.ok(t,'FINISH_WITHOUT_BEGIN');transfers.delete(m.runId);
      const result=await pages[t.slot].evaluate(src=>{
       try {return {ok:true,result:(0,eval)(src)}}
       catch(e){return {ok:false,reason:String(e?.message||e)}}
      },t.src);
      reply.result=JSON.stringify(JSON.stringify(result));
     }else if(m.op==='navigate'){
      assert.equal(m.url,'https://chatgpt.com/');
      await pages[m.slot].goto(m.url,{waitUntil:'domcontentloaded'});
     }else{
      throw Error('UNEXPECTED_HOST_OP:'+m.op);
     }
    }catch(e){reply.ok=false;reply.reason=String(e.message||e)}
    await dash.evaluate((id,data)=>{window.DexaResolve?.(id,data)},m.id,reply);
   });
   await dash.evaluateOnNewDocument(()=>{
    window.DexaHost={send(raw){window.__nativeSend(JSON.parse(raw))}};
   });
   await dash.goto(URL,{waitUntil:'networkidle2'});
   await dash.evaluate(s=>window.onDexaHostUpdate(s),hostState);
   await dash.waitForFunction(()=>window.DexaCycle&&document.querySelector('#boardTabs'));
   await dash.evaluate(()=>{
    const b=[...document.querySelectorAll('#boardTabs button')].find(b=>b.textContent.includes('ورودی و خروجی'));
    if(!b)throw Error('CYCLE_TAB_NOT_FOUND');b.click();
   });
   await dash.waitForSelector('#dexaCyclePanel');
   await dash.click('[data-cycle-example]');
   const configuration=await dash.evaluate(()=>({
    first:document.querySelector('#cycleFirst').value,second:document.querySelector('#cycleSecond').value,
    voice:document.querySelector('#cycleVoice').checked,
    wrapper:document.querySelector('#cycleWrapper').value,
    prompt:document.querySelector('#cyclePrompt').value,
    source:window.DexaCycle.read()
   }));
   assert.equal(configuration.first,'Instant');
   assert.equal(configuration.second,'Instant');
   assert.equal(configuration.voice,false);
   assert.equal(configuration.wrapper,'این سؤال را حل کن و جوابش را بده.');
   assert.match(configuration.prompt,/ضرب/);
   await dash.click('[data-cycle-run]');
   // Deliberate duplicate click while first run is active MUST NOT send twice.
   await dash.click('[data-cycle-run]').catch(()=>{});
   const timeout=Date.now()+45000;
   let state;
   while(Date.now()<timeout){
    state=await dash.evaluate(()=>window.DexaCycle.read());
    if(!state.running&&['DONE','FAILED','ANSWER_INCORRECT','DRAFT_RESTORE_PENDING'].includes(state.stage))break;
    await sleep(200);
   }
   const output=await dash.evaluate(()=>({
    status:window.DexaCycle.read(),
    question:document.querySelector('[data-cycle-question]').value,
    answer:document.querySelector('[data-cycle-output]').value,
    validation:document.querySelector('[data-cycle-validation]').textContent
   }));
   const stats=await Promise.all(pages.map(p=>p.evaluate(()=>({...window.__mock,location:location.pathname}))));
   assert.equal(output.status.stage,expectedStage,JSON.stringify(output));
   assert.equal(stats[0].sendCount,1,'SLOT_0_MUST_SEND_EXACTLY_ONCE');
   assert.equal(stats[1].sendCount,expectedSends[1],'SLOT_1_EXPECTED_SEND_COUNT');
   assert.equal(stats[0].lastPrompt,configuration.prompt,'FIRST_SOURCE_MESSAGE_EXACT');
   assert.equal(stats[1].sendCount?stats[1].lastPrompt.includes('این سؤال را حل کن و جوابش را بده.') : false,expectedSends[1]===1);
   if(expectedStage==='DONE'){
    assert.equal(output.question,'۷ × ۶ = ؟');
    assert.equal(output.answer,'۴۲');
    assert.match(output.validation,/42/);
   }
   if(expectedStage==='ANSWER_INCORRECT'){
    assert.equal(output.answer,'۴۱');
    assert.match(output.validation,/41/);
    assert.match(output.validation,/42/);
   }
   console.log('REAL_CHROMIUM_SIMULATED_ANDROID_CYCLE_'+name+'_PASS',JSON.stringify({
    stage:output.status.stage,firstQuestion:output.question,secondAnswer:output.answer,
    validation:output.validation,sends:stats.map(x=>x.sendCount),sourceMatches:stats[0].lastPrompt===configuration.prompt
   }));
   await Promise.all([...pages,dash].map(p=>p.close()));
  }
  await scenario('CORRECT','correct','DONE',[1,1]);
  await scenario('WRONG_ANSWER','wrong','ANSWER_INCORRECT',[1,1]);
  await scenario('INVALID_QUESTION','malformed','FAILED',[1,0]);
  console.log('BROWSER_INTEGRATION_3_OF_3_PASS__FIXTURE_ONLY_NOT_REAL_CHATGPT');
 }finally{await browser.close()}
}
try {await main()}finally{server.kill('SIGTERM')}
