import http from 'node:http';
import {createRemoteGateway} from './remote-gateway.mjs';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
const html=fs.readFileSync(path.join(dir,'index.html'));
const toolbar=fs.readFileSync(path.join(dir,'toolbar.html'));
const theme=fs.readFileSync(path.join(dir,'theme.css'));
const themeClient=fs.readFileSync(path.join(dir,'theme-client.js'));
const autoHandoff=fs.readFileSync(path.join(dir,'auto-handoff.js'));
const cyclePanel=fs.readFileSync(path.join(dir,'cycle-panel.js'));
const port=Number(process.env.PORT||4000);
const recent=[];
const counts=new Map();
const started=Date.now();
const remoteGateway=createRemoteGateway();
function response(res,status,body,type='application/json; charset=utf-8'){
  res.writeHead(status,{'content-type':type,'cache-control':'no-store','x-content-type-options':'nosniff','x-frame-options':'DENY','access-control-allow-origin':'*'});
  res.end(body);
}
function json(res,status,obj){response(res,status,JSON.stringify(obj));}
const config={
  schema:'dexa-super-dashboard.v1',name:'داشبورد دکسا',build:'web-v1.6.39',
  browserHome:'https://chatgpt.com/',defaultBrowsers:2,maxBrowsers:8,maxDashboards:8,
  desiredBrowserCount:null,
  dashboards:[{id:'control',title:'کنترل دکسا',description:'مدیریت مرورگرها'},{id:'cycle',title:'ورودی و خروجی',description:'چرخهٔ دو مرورگر'},{id:'development',title:'توسعه',description:'چت جدید برای دو مرورگر'},{id:'theme',title:'تم رنگی'},{id:'permissions',title:'دسترسی‌های اندروید'}],
  permissions: [
    {id:'android.permission.ACCEPT_HANDOVER',label:'ACCEPT_HANDOVER',group:'تماس و پیام'},
    {id:'android.permission.ACCESS_BACKGROUND_LOCATION',label:'ACCESS_BACKGROUND_LOCATION',group:'مکان و فاصله'},
    {id:'android.permission.ACCESS_COARSE_LOCATION',label:'ACCESS_COARSE_LOCATION',group:'مکان و فاصله'},
    {id:'android.permission.ACCESS_FINE_LOCATION',label:'ACCESS_FINE_LOCATION',group:'مکان و فاصله'},
    {id:'android.permission.ACCESS_LOCAL_NETWORK',label:'ACCESS_LOCAL_NETWORK',group:'شبکه و ارتباطات'},
    {id:'android.permission.ACCESS_MEDIA_LOCATION',label:'ACCESS_MEDIA_LOCATION',group:'مکان و فاصله'},
    {id:'android.permission.ACTIVITY_RECOGNITION',label:'ACTIVITY_RECOGNITION',group:'سیستم و دسترسی‌های ویژه'},
    {id:'android.permission.ADD_VOICEMAIL',label:'ADD_VOICEMAIL',group:'تماس و پیام'},
    {id:'android.permission.ANSWER_PHONE_CALLS',label:'ANSWER_PHONE_CALLS',group:'تماس و پیام'},
    {id:'android.permission.BLUETOOTH_ADVERTISE',label:'BLUETOOTH_ADVERTISE',group:'شبکه و ارتباطات'},
    {id:'android.permission.BLUETOOTH_CONNECT',label:'BLUETOOTH_CONNECT',group:'شبکه و ارتباطات'},
    {id:'android.permission.BLUETOOTH_SCAN',label:'BLUETOOTH_SCAN',group:'شبکه و ارتباطات'},
    {id:'android.permission.BODY_SENSORS',label:'BODY_SENSORS',group:'سیستم و دسترسی‌های ویژه'},
    {id:'android.permission.BODY_SENSORS_BACKGROUND',label:'BODY_SENSORS_BACKGROUND',group:'سیستم و دسترسی‌های ویژه'},
    {id:'android.permission.CALL_PHONE',label:'CALL_PHONE',group:'تماس و پیام'},
    {id:'android.permission.CAMERA',label:'CAMERA',group:'رسانه و صدا'},
    {id:'android.permission.GET_ACCOUNTS',label:'GET_ACCOUNTS',group:'تقویم و مخاطبان'},
    {id:'android.permission.NEARBY_WIFI_DEVICES',label:'NEARBY_WIFI_DEVICES',group:'شبکه و ارتباطات'},
    {id:'android.permission.POST_NOTIFICATIONS',label:'POST_NOTIFICATIONS',group:'سرویس و اعلان'},
    {id:'android.permission.PROCESS_OUTGOING_CALLS',label:'PROCESS_OUTGOING_CALLS',group:'تماس و پیام'},
    {id:'android.permission.RANGING',label:'RANGING',group:'مکان و فاصله'},
    {id:'android.permission.READ_CALENDAR',label:'READ_CALENDAR',group:'تقویم و مخاطبان'},
    {id:'android.permission.READ_CALL_LOG',label:'READ_CALL_LOG',group:'تماس و پیام'},
    {id:'android.permission.READ_CONTACTS',label:'READ_CONTACTS',group:'تقویم و مخاطبان'},
    {id:'android.permission.READ_EXTERNAL_STORAGE',label:'READ_EXTERNAL_STORAGE',group:'حافظه و فایل'},
    {id:'android.permission.READ_MEDIA_AUDIO',label:'READ_MEDIA_AUDIO',group:'رسانه و صدا'},
    {id:'android.permission.READ_MEDIA_IMAGES',label:'READ_MEDIA_IMAGES',group:'رسانه و صدا'},
    {id:'android.permission.READ_MEDIA_VIDEO',label:'READ_MEDIA_VIDEO',group:'رسانه و صدا'},
    {id:'android.permission.READ_MEDIA_VISUAL_USER_SELECTED',label:'READ_MEDIA_VISUAL_USER_SELECTED',group:'رسانه و صدا'},
    {id:'android.permission.READ_PHONE_NUMBERS',label:'READ_PHONE_NUMBERS',group:'تماس و پیام'},
    {id:'android.permission.READ_PHONE_STATE',label:'READ_PHONE_STATE',group:'تماس و پیام'},
    {id:'android.permission.READ_SMS',label:'READ_SMS',group:'تماس و پیام'},
    {id:'android.permission.RECEIVE_MMS',label:'RECEIVE_MMS',group:'تماس و پیام'},
    {id:'android.permission.RECEIVE_SMS',label:'RECEIVE_SMS',group:'تماس و پیام'},
    {id:'android.permission.RECEIVE_WAP_PUSH',label:'RECEIVE_WAP_PUSH',group:'تماس و پیام'},
    {id:'android.permission.RECORD_AUDIO',label:'RECORD_AUDIO',group:'رسانه و صدا'},
    {id:'android.permission.SEND_SMS',label:'SEND_SMS',group:'تماس و پیام'},
    {id:'android.permission.USE_SIP',label:'USE_SIP',group:'تماس و پیام'},
    {id:'android.permission.UWB_RANGING',label:'UWB_RANGING',group:'مکان و فاصله'},
    {id:'android.permission.WRITE_CALENDAR',label:'WRITE_CALENDAR',group:'تقویم و مخاطبان'},
    {id:'android.permission.WRITE_CALL_LOG',label:'WRITE_CALL_LOG',group:'تماس و پیام'},
    {id:'android.permission.WRITE_CONTACTS',label:'WRITE_CONTACTS',group:'تقویم و مخاطبان'},
    {id:'android.permission.WRITE_EXTERNAL_STORAGE',label:'WRITE_EXTERNAL_STORAGE',group:'حافظه و فایل'},
    {id:'android.permission.FOREGROUND_SERVICE_SPECIAL_USE',label:'FOREGROUND_SERVICE_SPECIAL_USE',group:'سرویس و اعلان'},
    {id:'android.permission.INSTANT_APP_FOREGROUND_SERVICE',label:'INSTANT_APP_FOREGROUND_SERVICE',group:'سرویس و اعلان'},
    {id:'android.permission.INTERACT_ACROSS_PROFILES',label:'INTERACT_ACROSS_PROFILES',group:'سیستم و دسترسی‌های ویژه'},
    {id:'android.permission.LOADER_USAGE_STATS',label:'LOADER_USAGE_STATS',group:'حافظه و فایل'},
    {id:'android.permission.MANAGE_EXTERNAL_STORAGE',label:'MANAGE_EXTERNAL_STORAGE',group:'حافظه و فایل'},
    {id:'android.permission.MANAGE_MEDIA',label:'MANAGE_MEDIA',group:'رسانه و صدا'},
    {id:'android.permission.MANAGE_ONGOING_CALLS',label:'MANAGE_ONGOING_CALLS',group:'تماس و پیام'},
    {id:'android.permission.MEDIA_ROUTING_CONTROL',label:'MEDIA_ROUTING_CONTROL',group:'رسانه و صدا'},
    {id:'android.permission.PACKAGE_USAGE_STATS',label:'PACKAGE_USAGE_STATS',group:'سیستم و دسترسی‌های ویژه'},
    {id:'android.permission.POST_PROMOTED_NOTIFICATIONS',label:'POST_PROMOTED_NOTIFICATIONS',group:'سرویس و اعلان'},
    {id:'android.permission.REQUEST_INSTALL_PACKAGES',label:'REQUEST_INSTALL_PACKAGES',group:'سیستم و دسترسی‌های ویژه'},
    {id:'android.permission.SCHEDULE_EXACT_ALARM',label:'SCHEDULE_EXACT_ALARM',group:'سرویس و اعلان'},
    {id:'android.permission.SMS_FINANCIAL_TRANSACTIONS',label:'SMS_FINANCIAL_TRANSACTIONS',group:'تماس و پیام'},
    {id:'android.permission.SYSTEM_ALERT_WINDOW',label:'SYSTEM_ALERT_WINDOW',group:'سیستم و دسترسی‌های ویژه'},
    {id:'android.permission.TURN_SCREEN_ON',label:'TURN_SCREEN_ON',group:'سرویس و اعلان'},
    {id:'android.permission.USE_FULL_SCREEN_INTENT',label:'USE_FULL_SCREEN_INTENT',group:'سرویس و اعلان'},
    {id:'android.permission.USE_ICC_AUTH_WITH_DEVICE_IDENTIFIER',label:'USE_ICC_AUTH_WITH_DEVICE_IDENTIFIER',group:'تماس و پیام'},
    {id:'android.permission.WRITE_SETTINGS',label:'WRITE_SETTINGS',group:'سیستم و دسترسی‌های ویژه'},
    {id:'android.permission.WRITE_SYSTEM_PREFERENCES',label:'WRITE_SYSTEM_PREFERENCES',group:'سیستم و دسترسی‌های ویژه'},
    {id:'default_sms',label:'نقش برنامهٔ پیش‌فرض پیامک',group:'نقش‌ها'},
    {id:'notification_listener',label:'دسترسی به اعلان‌های گوشی',group:'نقش‌ها'},
    {id:'dnd',label:'مدیریت مزاحم نشوید',group:'دسترسی ویژه'},
    {id:'saf_tree',label:'پوشهٔ انتخاب‌شده',group:'دسترسی ویژه'},
    {id:'overlay',label:'نمایش روی برنامه‌های دیگر',group:'دسترسی ویژه'},
    {id:'usage_access',label:'آمار استفاده',group:'دسترسی ویژه'},
    {id:'write_settings',label:'تغییر تنظیمات',group:'دسترسی ویژه'},
    {id:'accessibility',label:'دسترس‌پذیری',group:'دسترسی ویژه'},
    {id:'exact_alarm',label:'هشدار دقیق',group:'دسترسی ویژه'},
    {id:'install_packages',label:'نصب برنامه',group:'دسترسی ویژه'},
    {id:'background_location',label:'مکان در پس‌زمینه',group:'دسترسی ویژه'},
    {id:'battery_exempt',label:'معافیت بهینه‌سازی باتری',group:'دسترسی ویژه'}
  ],

  actions:{
    observe:{label:'وضعیت صفحه',code:"(()=>({host:location.host,turnCount:document.querySelectorAll('[data-message-author-role]').length,voiceButtons:document.querySelectorAll('button[aria-label*=Voice],button[aria-label*=voice]').length}))()"},
    new_chat:{label:'گفت‌وگوی جدید',code:"(()=>{const a=[...document.querySelectorAll('a,button')].find(e=>{let t=((e.getAttribute('aria-label')||'')+' '+(e.textContent||'')).trim();return /new chat|چت جدید|گفتگوی جدید/i.test(t)});if(!a)return {ok:false,reason:'CONTROL_NOT_FOUND'};a.click();return {ok:true,action:'new_chat'}})()"},
    stop:{label:'توقف پاسخ',code:"(()=>{const b=[...document.querySelectorAll('button')].find(e=>/stop generating|stop response|توقف پاسخ/i.test(e.getAttribute('aria-label')||''));if(!b)return {ok:false,reason:'CONTROL_NOT_FOUND'};b.click();return {ok:true,action:'stop'}})()"}
  }
};
// Hard schema for UI telemetry. No arbitrary DOM attributes, text or URLs.
const uiTags=new Set(['button','a','div','span','svg','path','g','img','input','textarea','form','label',
  'article','section','main','ul','li','p','figure','figcaption','picture','canvas','video','strong',
  'i','small','time','header','footer','aside','summary','select','option','output','circle','rect','line','polyline','polygon','use','other']);
const uiRoles=new Set(['button','link','textbox','group','listitem','menuitem','img','dialog','form','other','none']);
const uiTests=new Set(['send-button','voice-send-button','composer-plus-btn','prompt-textarea',
  'remove','attachment','send','composer','other','none']);
const uiSemantics=new Set(['remove','attachment','send','close','add','none']);
const uiKinds=new Set(['click','pointer','file_change','result']);
const uiNumber=(n,max=250)=>Number.isInteger(n)?Math.max(0,Math.min(n,max)):0;
const uiEnum=(x,allowed,otherwise='other')=>typeof x==='string'&&allowed.has(x)?x:otherwise;
function uiPath(v,max=10){
  if(!Array.isArray(v))return [];
  return v.slice(0,max).filter(x=>{
    if(typeof x!=='string'||x.length>24)return false;
    const m=/^([a-z]+):([0-9]{1,2})$/.exec(x);
    return m&&uiTags.has(m[1]);
  });
}
function uiShape(v){
  if(!v||typeof v!=='object')v={};
  const out={tag:uiEnum(v.tag,uiTags),role:uiEnum(v.role,uiRoles,'none'),
    test:uiEnum(v.test,uiTests,'none'),semantic:uiEnum(v.semantic,uiSemantics,'none'),
    path:uiPath(v.path,10),children:uiNumber(v.children,40),
    buttons:uiNumber(v.buttons,30),media:uiNumber(v.media,30)};
  if(Array.isArray(v.parentPath))out.parentPath=uiPath(v.parentPath,6);
  if(typeof v.hit==='boolean')out.hit=v.hit;
  return out;
}
function uiCounts(v){
  return Object.fromEntries(['attachments','removeCandidates','iconControls','controls']
    .map(k=>[k,uiNumber(v?.[k],250)]));
}
function cleanUiEvent(a){
  if(!a||typeof a!=='object'||![0,1].includes(a.slot))return null;
  if(typeof a.session!=='string'||!(/^[a-z0-9]{16,40}$/).test(a.session))return null;
  if(typeof a.id!=='string'||!new RegExp('^ui-'+a.session+'-[0-9]{1,12}$').test(a.id))return null;
  if(!Number.isSafeInteger(a.time)||a.time<0)return null;
  const d=a.detail;
  if(!d||typeof d!=='object'||!uiKinds.has(d.kind))return null;
  if(a.event==='DEXA_UI_CONTROL' && d.kind==='result')return null;
  if(a.event==='DEXA_UI_DOM' && d.kind!=='result')return null;
  const out={event:a.event,slot:a.slot,id:a.id,session:a.session,
    time:a.time,build:'web-v1.6.39',
    detail:{kind:d.kind,trusted:d.trusted===true,
      control:uiShape(d.control),ref:typeof d.ref==='string'&&/^a[0-9]{1,12}$/.test(d.ref)?d.ref:'none',
      before:uiCounts(d.before)}};
  const t=out.detail;
  if(a.event==='DEXA_UI_CONTROL'){
    t.target=uiShape(d.target);
    t.nested=d.nested===true;
    t.path=uiPath(d.path);
    t.relation=Object.fromEntries(['inComposer','inForm','nearComposer','nearAttachment']
      .map(k=>[k,d.relation?.[k]===true]));
  }else{
    t.after=uiCounts(d.after);
    const m=d.mutation||{};
    t.mutation={
      added:uiNumber(m.added,80),removed:uiNumber(m.removed,80),
      attribute:uiNumber(m.attribute,80),
      removedNodes:Array.isArray(m.removedNodes)?m.removedNodes.slice(0,4).map(uiShape):[],
      addedNodes:Array.isArray(m.addedNodes)?m.addedNodes.slice(0,3).map(uiShape):[],
      controlGone:m.controlGone===true,targetGone:m.targetGone===true,
      containsControl:m.containsControl===true,
      attachmentDecrease:m.attachmentDecrease===true,
      removalDecrease:m.removalDecrease===true,anyChange:m.anyChange===true
    };
  }
  return out;
}
const uiSeen=new Set(),uiSeenOrder=[];

function cleanEvent(a){
  if(a && (a.event==='DEXA_UI_CONTROL'||a.event==='DEXA_UI_DOM'))return cleanUiEvent(a);
  if(!a || typeof a!=='object')return null;
  const allowed=['id','session','device','build','event','slot','time','code','action','error','host','visible','count','pending','phase','ok','durationMs','observedAt','receivedAt','updatedAt'];
  const o={};
  for(const k of allowed)if(Object.hasOwn(a,k)){
    const v=a[k];
    if(typeof v==='string')o[k]=v.slice(0,100);
    else if(typeof v==='boolean' || typeof v==='number')o[k]=v;
  }
  if(!/^[A-Z][A-Z0-9_]{2,55}$/.test(o.event||''))return null;
  return o;
}
const srv=http.createServer(async(req,res)=>{
  const url=new URL(req.url||'/', 'http://local');
  if(url.pathname.startsWith('/api/remote/'))return remoteGateway(req,res,url);
  if(req.method==='GET' && url.pathname==='/api/health')return json(res,200,{ok:true,service:'dexa-super-dashboard',uptimeSeconds:Math.floor((Date.now()-started)/1000),eventsSeen:[...counts.values()].reduce((a,b)=>a+b,0),webVersion:config.build});
  if(req.method==='GET' && url.pathname==='/api/config')return json(res,200,config);
  if(req.method==='GET' && url.pathname==='/api/telemetry/summary')return json(res,200,{ok:true,total:recent.length,byEvent:Object.fromEntries(counts)});
  if(req.method==='GET' && url.pathname==='/theme.css')return response(res,200,theme,'text/css; charset=utf-8');
  if(req.method==='GET' && url.pathname==='/remote-client.js')return response(res,200,fs.readFileSync(path.join(dir,'remote-client.js')),'application/javascript; charset=utf-8');
  if(req.method==='GET' && url.pathname==='/theme-client.js')return response(res,200,themeClient,'application/javascript; charset=utf-8');
  if(req.method==='GET' && url.pathname==='/auto-handoff.js')return response(res,200,autoHandoff,'application/javascript; charset=utf-8');
  if(req.method==='GET' && url.pathname==='/cycle-panel.js')return response(res,200,cyclePanel,'application/javascript; charset=utf-8');
  if(req.method==='GET' && url.pathname==='/toolbar')return response(res,200,toolbar,'text/html; charset=utf-8');
  if(req.method==='GET' && (url.pathname==='/'||url.pathname==='/dashboard'))return response(res,200,html,'text/html; charset=utf-8');
  if(req.method==='POST' && url.pathname==='/api/telemetry'){
    let size=0,body='';
    try{for await(const chunk of req){size+=chunk.length;if(size>8192){json(res,413,{ok:false,reason:'TOO_LARGE'});return;}body+=chunk.toString('utf8');}}
    catch{json(res,400,{ok:false});return;}
    let raw;try{raw=JSON.parse(body)}catch{json(res,400,{ok:false,reason:'BAD_JSON'});return;}
    const event=cleanEvent(raw);
    if(!event)return json(res,422,{ok:false,reason:'INVALID_EVENT'});
    const responseEvent=event.event.startsWith('RESPONSE_')||
      event.event==='ACCESSIBILITY_STATUS_CHANGED';
    if(responseEvent){
      if(!/^rsp-[a-f0-9]{16}-[0-9]+(?:-d)?$/.test(event.id||''))
        return json(res,422,{ok:false,reason:'RESPONSE_EVENT_ID_INVALID'});
      for(const t of ['observedAt','receivedAt','updatedAt'])
        if(!Number.isSafeInteger(event[t])||event[t]<1000000000000||event[t]>4102444800000)
          return json(res,422,{ok:false,reason:'RESPONSE_TIMESTAMP_INVALID'});
    }
    const dedupe=responseEvent||event.event==='DEXA_UI_CONTROL'||event.event==='DEXA_UI_DOM';
    if(dedupe && uiSeen.has(event.id))
      return json(res,202,{ok:true,id:event.id,duplicate:true});
    if(dedupe){
      uiSeen.add(event.id);uiSeenOrder.push(event.id);
      if(uiSeenOrder.length>5000)uiSeen.delete(uiSeenOrder.shift());
    }
    recent.push(event);if(recent.length>2000)recent.shift();
    counts.set(event.event,(counts.get(event.event)||0)+1);
    console.log('DXA_TELEM '+JSON.stringify(event));
    return json(res,202,{ok:true,id:event.id||null});
  }
  return json(res,404,{ok:false,reason:'NOT_FOUND'});
});
srv.listen(port,process.env.DEXA_BIND_HOST||'127.0.0.1',()=>console.log('DXA_SUPER_DASHBOARD_READY port='+port));