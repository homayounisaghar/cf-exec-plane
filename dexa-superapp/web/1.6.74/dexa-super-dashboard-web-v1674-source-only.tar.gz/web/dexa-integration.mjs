// Dexa dashboard -> existing owner-authenticated Rana.
// ONE owner-authorized public GitHub page includes original catalog + rolling 30 exchanges.
// The original Rana recipe execution API remains owner-paired and private.
import fs from 'node:fs';
import path from 'node:path';
import {createHash,randomBytes,timingSafeEqual} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';

const HERE=path.dirname(fileURLToPath(import.meta.url));
const SECRET_DIR=process.env.DEXA_INTEGRATION_DIR||
  '/home/cfserver/.config/dexa-integration';
const CORE='http://127.0.0.1:9471';
const PUBLIC=process.env.DEXA_SUPERAPP_PUBLIC_ORIGIN||
  'https://cf-onshape.duckdns.org/dexa-superapp';
const WORKER_ORIGIN='https://dexa-cf-worker-canary-20261104.mirkazem.workers.dev';
const TRUSTED_ORIGINS=new Set([new URL(PUBLIC).origin,WORKER_ORIGIN]);
// Android v18 loads the dashboard through Cloudflare. That Worker currently
// rejects every newly added /api/dexa route with bare 404 NOT_ALLOWED.
// Browser requests therefore reach the canonical HTTPS endpoint directly,
// strictly CORS-gated to the single owner-controlled Worker origin.

const SINGLE_PUBLIC_CATALOG='https://raw.githubusercontent.com/homayounisaghar/cf-exec-plane/main/dexa/catalog-mvp.md';
const PUBLISHER=path.join(HERE,'..','sync','publish-catalog-history.py');
const sha=s=>createHash('sha256').update(s).digest('hex');
const secretPath=n=>path.join(SECRET_DIR,n);
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const HEX=/^[0-9a-f]{64}$/;
function safeDigestMatch(given,stored){
 if(typeof given!=='string'||!HEX.test(given))return false;
 return timingSafeEqual(Buffer.from(given,'hex'),Buffer.from(stored,'hex'));
}
function readPrivate(name){
 try{
  const p=secretPath(name),st=fs.statSync(p);
  if(!st.isFile()||(st.mode&0o077)!==0)return null;
  return fs.readFileSync(p,'utf8').trim();
 }catch{return null}
}
function ownerOkay(req){
 const token=String(req.headers['x-dexa-owner-token']||'');
 if(!HEX.test(token))return false;
 const proof=sha(token);
 // Original browser and second device each keep their own 256-bit bearer.
 return ['owner-token.sha256','owner-token-mobile.sha256'].some(name=>{
  const hash=readPrivate(name);
  return !!hash&&HEX.test(hash)&&safeDigestMatch(proof,hash);
 });
}
function noStore(res,code,body,type='application/json; charset=utf-8'){
 res.writeHead(code,{'content-type':type,'cache-control':'no-store, private',
  'x-content-type-options':'nosniff','x-frame-options':'DENY',
  'x-robots-tag':'noindex, nofollow, noarchive',
  'referrer-policy':'no-referrer',
  'content-security-policy':"default-src 'none'; frame-ancestors 'none'; base-uri 'none'"});
 res.end(type.startsWith('application/json')?JSON.stringify(body):body);
}
const json=(res,code,body)=>noStore(res,code,body);
async function readJson(req,max=90000){
 const chunks=[];let size=0;
 for await(const chunk of req){
  size+=chunk.length;
  if(size>max)throw Error('DEXA_REQUEST_TOO_LARGE');
  chunks.push(chunk);
 }
 try{return JSON.parse(Buffer.concat(chunks).toString('utf8'))}
 catch{throw Error('DEXA_REQUEST_JSON_INVALID')}
}
function isOwnerOrigin(req){
 const origin=req.headers.origin;
 // WebView JSON POST supplies Origin; reject foreign sites before any action.
 return typeof origin==='string'&&TRUSTED_ORIGINS.has(origin);
}
async function engine(method,endpoint,body=null){
 const key=readPrivate('engine-bridge-key');
 if(!key||!HEX.test(key))throw Error('DEXA_ENGINE_NOT_CONFIGURED');
 const r=await fetch(CORE+endpoint,{method,
  headers:{'x-dexa-superapp-bridge-key':key,
   ...(body?{'content-type':'application/json'}:{})},
  ...(body?{body:JSON.stringify(body)}:{})});
 let data;
 try{data=await r.json()}catch{throw Error('DEXA_ENGINE_RESPONSE_INVALID')}
 return {ok:r.ok,status:r.status,data};
}
const asCode=e=>String(e?.message||e||'UNKNOWN')
 .replace(/[^A-Z0-9_]/gi,'_').slice(0,85);
// Publication is serialized: the next owner run sees all completed preceding exchanges.
let publishQueue=Promise.resolve();
function publishPublicCatalog(exchanges){
 const task=publishQueue.then(()=>new Promise((resolve,reject)=>{
  const child=spawn('python3',[PUBLISHER],{stdio:['pipe','pipe','pipe']});
  let output='',errors='';
  child.stdout.on('data',x=>{output+=x.toString('utf8').slice(0,10000)});
  child.stderr.on('data',x=>{errors+=x.toString('utf8').slice(0,500)});
  child.on('error',()=>reject(Error('DEXA_PUBLIC_CATALOG_PROCESS_UNAVAILABLE')));
  child.on('close',code=>{
   let result;
   try{result=JSON.parse(output.trim())}catch{
    return reject(Error('DEXA_PUBLIC_CATALOG_RESPONSE_INVALID'))}
   if(code!==0||result.ok!==true)
    return reject(Error(String(result.error||'DEXA_PUBLIC_CATALOG_SYNC_FAILED')
      .replace(/[^A-Z0-9_]/gi,'_').slice(0,90)));
   if(typeof result.url!=='string'||
      !/^https:\/\/raw\.githubusercontent\.com\/homayounisaghar\/cf-exec-plane\/[a-f0-9]{40}\/dexa\/catalog-mvp\.md$/.test(result.url))
    return reject(Error('DEXA_PUBLIC_CATALOG_URL_INVALID'));
   resolve(result);
  });
  child.stdin.on('error',()=>{});
  child.stdin.end(JSON.stringify({exchanges}));
 }));
 publishQueue=task.catch(()=>{});
 return task;
}
export function createDexaIntegration({engineTransport=engine,catalogPublisher=publishPublicCatalog}={}){
 return async (req,res,url)=>{
  const p=url.pathname;
  if(p.startsWith('/api/dexa/')){
   const cross=req.headers.origin===WORKER_ORIGIN;
   if(cross){
    res.setHeader('Access-Control-Allow-Origin',WORKER_ORIGIN);
    res.setHeader('Vary','Origin');
   }
   if(req.method==='OPTIONS'){
    // Preflight performs no pairing, admission, or other engine action.
    if(!cross)return json(res,403,{error:'CORS_ORIGIN_DENIED'});
    res.writeHead(204,{'Access-Control-Allow-Methods':'GET, POST, OPTIONS',
     'Access-Control-Allow-Headers':'Content-Type, X-Dexa-Owner-Token',
     'Access-Control-Max-Age':'0','Cache-Control':'no-store'});
    res.end();return true;
   }
  }
  if(!p.startsWith('/api/dexa/'))return false;
  try{
   if(req.method==='GET'&&p==='/api/dexa/pair/status')
    return json(res,200,{paired:!!readPrivate('owner-token.sha256'),
     thisBrowserPaired:ownerOkay(req),
     secondDevicePaired:!!readPrivate('owner-token-mobile.sha256'),
     configured:!!readPrivate('engine-bridge-key')});
   if(req.method==='POST'&&p==='/api/dexa/pair'){
    if(!isOwnerOrigin(req))return json(res,403,{error:'OWNER_ORIGIN_REQUIRED'});
    const body=await readJson(req,2000);
    const first=!!readPrivate('owner-token.sha256');
    const saved=readPrivate(first?'owner-pair-invite.sha256':
                                 'owner-pair-code.sha256');
    if(first&&readPrivate('owner-token-mobile.sha256'))
     return json(res,409,{error:'SECOND_DEVICE_ALREADY_PAIRED'});
    if(!saved||!HEX.test(saved)||typeof body.code!=='string'||
      !safeDigestMatch(sha(body.code.trim()),saved))
     return json(res,first?409:403,
      {error:first?'PAIR_CODE_CONSUMED_REQUEST_FRESH_DEVICE_CODE':'PAIR_CODE_NOT_ACCEPTED'});
    const token=randomBytes(32).toString('hex');
    const target=first?'owner-token-mobile.sha256':'owner-token.sha256';
    fs.writeFileSync(secretPath(target),sha(token)+'\n',
      {flag:'wx',mode:0o600});
    fs.unlinkSync(secretPath(first?'owner-pair-invite.sha256':
                                 'owner-pair-code.sha256'));
    return json(res,200,{ok:true,ownerToken:token});
   }
   if(!ownerOkay(req))return json(res,401,{error:'DEXA_OWNER_PAIR_REQUIRED'});
   if(req.method==='POST'&&p==='/api/dexa/pair/invite'){
    if(!isOwnerOrigin(req))return json(res,403,{error:'OWNER_ORIGIN_REQUIRED'});
    if(readPrivate('owner-token-mobile.sha256'))
     return json(res,409,{error:'SECOND_DEVICE_ALREADY_PAIRED'});
    const code=randomBytes(16).toString('hex');
    fs.writeFileSync(secretPath('owner-pair-invite.sha256'),
     sha(code)+'\n',{mode:0o600});
    return json(res,200,{ok:true,code});
   }
   if(req.method==='GET'&&p==='/api/dexa/status'){
    const r=await engineTransport('GET','/healthz');
    return json(res,r.ok?200:502,{ok:r.ok,
     engineReady:r.data?.ok===true,storedMissions:r.data?.storedMissions||0,
     activeMissions:r.data?.activeMissions||0});
   }
   if(req.method==='POST'&&!isOwnerOrigin(req))
    return json(res,403,{error:'OWNER_ORIGIN_REQUIRED'});
   if(req.method==='POST'&&p==='/api/dexa/catalog/sync'){
    const body=await readJson(req,2000);
    if(!UUID.test(body.requestId||''))
     return json(res,400,{error:'CATALOG_RUN_ID_INVALID'});
    const r=await engineTransport('GET','/api/superapp/history');
    if(!r.ok)return json(res,502,{error:'DEXA_HISTORY_ENGINE_NOT_READY',
      engineError:r.data?.error||null});
    const published=await catalogPublisher(r.data?.exchanges||[]);
    console.log('DXA_PUBLIC_CATALOG_SYNC '+JSON.stringify({
     requestId:body.requestId,historyCount:published.historyCount,
     contentSha256:published.contentSha256,changed:published.changed}));
    return json(res,200,published);
   }
   if(req.method==='POST'&&p==='/api/dexa/execute'){
    const body=await readJson(req,80000);
    if(!UUID.test(body.requestId||'')||
       typeof body.goal!=='string'||body.goal.length<3||body.goal.length>5000||
       typeof body.recipe!=='string'||body.recipe.length<30||body.recipe.length>35000)
     return json(res,400,{error:'DEXA_RECIPE_SUBMISSION_INVALID'});
    // The owner explicitly selected ONE public catalog; Rana independently
    // validates actual recipe schemas and authorization. A model GET is not provable here.
    const r=await engineTransport('POST','/api/superapp/recipes',{
     requestId:body.requestId,goal:body.goal,recipe:body.recipe
    });
    // The Rana error.code already contains the exact sanitized parser
    // rejection. Retain it, with fetch evidence, without storing recipe text.
    const result=(r.data&&typeof r.data==='object')?r.data:
      {error:'DEXA_ENGINE_RESPONSE_INVALID'};
    const err=String(result.error||'NONE').replace(/[^A-Z0-9_]/gi,'_').slice(0,70);
    const detail=String(result.code||'NONE').replace(/[^A-Z0-9_]/gi,'_').slice(0,100);
    console.log('DXA_RECIPE_GATE '+JSON.stringify({
     requestId:body.requestId,httpStatus:r.status,
     result:err,parserCode:detail
    }));
    return json(res,r.status,result);
   }
   if(req.method==='GET'&&p==='/api/dexa/result'){
    const id=url.searchParams.get('requestId');
    if(!UUID.test(id||''))return json(res,400,{error:'RESULT_RUN_ID_INVALID'});
    const r=await engineTransport('GET','/api/superapp/recipes?requestId='+encodeURIComponent(id));
    // A completed owner/Rana pair is published to the SAME public page.
    // Publication failure does not hide or replay a real engine result:
    // the next run's catalog/sync retries before Browser1 submission.
    if(r.ok&&r.data?.terminal){
     try{
      const history=await engineTransport('GET','/api/superapp/history');
      if(!history.ok)throw Error('DEXA_HISTORY_ENGINE_NOT_READY');
      const published=await catalogPublisher(history.data?.exchanges||[]);
      console.log('DXA_PUBLIC_CATALOG_AFTER_RESULT '+JSON.stringify({
       requestId:id,historyCount:published.historyCount,
       contentSha256:published.contentSha256,changed:published.changed}));
     }catch(error){
      console.log('DXA_PUBLIC_CATALOG_AFTER_RESULT_ERROR '+JSON.stringify({
       requestId:id,code:asCode(error)}));
     }
    }
    return json(res,r.status,r.data);
   }
   return json(res,404,{error:'NOT_FOUND'});
  }catch(e){return json(res,503,{error:asCode(e)})}
 };
}
