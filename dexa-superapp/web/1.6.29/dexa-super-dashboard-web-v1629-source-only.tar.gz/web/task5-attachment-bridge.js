// Dexa Task 5: exclusively local, per-document ChatGPT file-input transfer.
// Loaded only by Android in the existing authenticated Browser 1 WebView.
// No network requests, no message Send, no filename or file data in diagnostics.
(function () {
  if (location.hostname !== 'chatgpt.com') return 'NOT_CHATGPT';
  const key = '__dexaTask5Local';
  const scopedFileInput = function(job) {
  // The active ChatGPT composer, not an arbitrary document-wide file input.
  const active=e=>!!e&&e.isConnected&&!e.disabled&&!e.readOnly&&
    e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden'&&
    !e.closest('[inert],[aria-hidden="true"]');
  const editors=[...document.querySelectorAll(
    '#prompt-textarea,[data-testid="prompt-textarea"],textarea,[contenteditable="true"][role="textbox"]'
  )].filter(active);
  const exact=editors.filter(e=>e.id==='prompt-textarea'||
    e.getAttribute('data-testid')==='prompt-textarea');
  const named=editors.filter(e=>/ask chatgpt|message|پیام|پرسش/i.test(
    [e.getAttribute('aria-label'),e.getAttribute('placeholder')]
      .filter(Boolean).join(' ')));
  const found=exact.length?exact:named.length?named:editors;
  if(found.length!==1)return {error:found.length?
    'CHATGPT_FILE_INPUT_AMBIGUOUS':'CHATGPT_FILE_INPUT_MISSING'};
  const composer=found[0],form=composer.closest('form');
  const usable=e=>!e.disabled&&!e.hasAttribute('capture')&&
    !e.hasAttribute('webkitdirectory')&&e.isConnected&&
    !e.parentElement?.closest('[inert],[aria-hidden="true"],[hidden]')&&
    !e.closest('dialog:not([open])');
  const all=[...document.querySelectorAll('input[type="file"]')].filter(usable);
  if(!all.length)return {error:'CHATGPT_FILE_INPUT_MISSING'};
  const acceptOK=e=>{
    const accept=(e.getAttribute('accept')||'').trim().toLowerCase();
    if(!accept||accept==='*/*')return true;
    const type=(job.file?.type||'').toLowerCase();
    const name=(job.file?.name||'').toLowerCase();
    return accept.split(',').some(raw=>{
      const rule=raw.trim();
      return rule==='*/*'||rule===type||
        (rule.startsWith('.')&&name.endsWith(rule))||
        (rule.endsWith('/*')&&type.startsWith(rule.slice(0,-1)));
    });
  };
  const compatible=all.filter(acceptOK);
  if(!compatible.length)return {error:'FILE_INPUT_REJECTED'};
  // Determine the nearest evidenced container enclosing the actual composer
  // AND an attachment control. A hidden input itself is valid; a file input
  // in an inert or unrelated hidden panel is not.
  const hasAttach=e=>[...e.querySelectorAll('button,[role="button"],label')]
    .some(b=>/add files and more|attach|upload files|composer-attach|پیوست|افزودن فایل/i.test(
      [b.getAttribute('aria-label'),b.getAttribute('data-testid'),
       b.getAttribute('title'),b.textContent].filter(Boolean).join(' ')));
  let scoped=[];
  if(form)scoped=compatible.filter(e=>form.contains(e)||e.form===form);
  if(!scoped.length){
    for(let a=composer.parentElement,depth=0;a&&a!==document.body&&depth<7;
        a=a.parentElement,depth++){
      if(!hasAttach(a))continue;
      const nearby=compatible.filter(e=>a.contains(e));
      if(nearby.length){scoped=nearby;break;}
    }
  }
  // A file input outside the composer subtree needs BOTH a semantic file
  // upload identity and an actual composer attachment control. A lone global
  // input can belong to an unrelated profile, image or inactive dialog.
  if(!scoped.length){
    let attachRoot=null;
    for(let a=composer.parentElement,depth=0;a&&a!==document.body&&depth<7;
        a=a.parentElement,depth++){
      if(hasAttach(a)){attachRoot=a;break;}
    }
    const identified=compatible.filter(e=>
      /file-upload|composer-file|attach-file|file-input/.test(
        [e.id,e.name,e.getAttribute('data-testid')].filter(Boolean)
          .join(' ').toLowerCase()));
    if(!attachRoot||identified.length!==1)
      return {error:'CHATGPT_FILE_INPUT_AMBIGUOUS'};
    scoped=identified;
  }
  if(scoped.length===1)return {input:scoped[0]};
  // The regular file-attachment input is preferable to a camera, image-only,
  // avatar or directory control, even when the file itself is an image.
  const generic=scoped.filter(e=>{
    const a=(e.getAttribute('accept')||'').trim().toLowerCase();
    return !a||a==='*/*';
  });
  if(generic.length===1)return {input:generic[0]};
  const choices=generic.length?generic:scoped;
  const explicit=choices.filter(e=>{
    const label=[e.id,e.name,e.getAttribute('data-testid'),
      e.getAttribute('aria-label')].filter(Boolean).join(' ').toLowerCase();
    return /file-upload|upload-file|composer-file|attach-file|file-input/.test(label)&&
      !/avatar|image|camera|profile|screenshot/.test(label);
  });
  if(explicit.length===1)return {input:explicit[0]};
  return {error:'CHATGPT_FILE_INPUT_AMBIGUOUS'};
};
  // Android v13 returns READY without overwriting a compatible bridge.
  // Patch the selection method IN PLACE if a transfer is already active.
  const existing=window[key];
  if(existing){
    if(existing.revision!=='task5-v13' ||
       ['prepare','append','commit','cancel','stop','report','tryDeliver',
        'findInput','exposeInput'].some(k=>typeof existing[k]!=='function'))
      return 'BRIDGE_CONTRACT_MISMATCH';
    existing.findInput=scopedFileInput;
    existing.selectorRevision='web-v1.6.29';
    return 'READY';
  }
  const bridge = {
    revision: 'task5-v13', state: null, last: null,
    prepare(token) {
      if (!/^[a-f0-9]{32}$/.test(token)) return 'INVALID_TOKEN';
      if (this.state) return 'TRANSFER_BUSY';
      this.last = null;
      this.state = {token, parts: [], stage: 'LOADING', file: null,
        observer: null, timer: null, openedMenu: false, clickedFiles: false,
        lastIssue: 'CHATGPT_FILE_INPUT_MISSING'};
      return 'READY';
    },
    append(token, encoded) {
      const job = this.state;
      if (!job || job.token !== token || job.stage !== 'LOADING')
        return 'TRANSFER_NOT_ACTIVE';
      try {
        const raw = atob(encoded), bytes = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
        job.parts.push(bytes);
        return 'APPENDED';
      } catch (_) { return 'FILE_TRANSFER_CHUNK_REJECTED'; }
    },
    stop(job) {
      if (job.observer) job.observer.disconnect();
      if (job.timer !== null) clearTimeout(job.timer);
      job.parts = null;
      job.file = null;
      if (this.state === job) this.state = null;
    },
    report(job, code) {
      if (this.state !== job || job.stage === 'DONE') return;
      job.stage = 'DONE';
      this.last = {token: job.token, code};
      this.stop(job);
      // The native WebChromeClient receives only this bounded technical token.
      console.info('DEXA_TASK5|' + job.token + '|' + code);
    },
    cancel(token) {
      const job = this.state;
      if (job && job.token === token) {
        if (job.stage === 'DONE') return 'ALREADY_DISPATCHED';
        this.stop(job);
        this.last = {token, code: 'CANCELLED'};
        return 'CANCELLED';
      }
      if (this.last?.token === token && this.last.code === 'INPUT_DISPATCHED')
        return 'ALREADY_DISPATCHED';
      return 'NOT_ACTIVE';
    },
    findInput: scopedFileInput,
    visible(el) {
      return !!el && el.getClientRects().length > 0 &&
        getComputedStyle(el).visibility !== 'hidden' &&
        !el.closest('[aria-hidden="true"],[inert]');
    },
    controls() {
      return [...document.querySelectorAll('button,[role="button"],[role="menuitem"]')]
        .filter(e => this.visible(e));
    },
    name(el) {
      return [el.getAttribute('aria-label'), el.getAttribute('title'),
        el.getAttribute('data-testid'), el.textContent]
        .filter(Boolean).join(' ').trim().toLowerCase();
    },
    exposeInput(job) {
      const all = this.controls();
      if (!job.openedMenu) {
        const add = all.filter(el =>
          /add files and more|attach files|add attachments|افزودن فایل|پیوست فایل|composer-attach-button/.test(this.name(el)));
        if (add.length === 1) {
          job.openedMenu = true;
          add[0].click();
          return;
        }
      }
      if (job.openedMenu && !job.clickedFiles) {
        const menu = all.filter(el =>
          el.getAttribute('role') === 'menuitem' ||
          !!el.closest('[role="menu"]'));
        const files = menu.filter(el =>
          /^(files|upload file|upload files|upload from computer|فایل‌ها|بارگذاری فایل)$/.test(this.name(el)));
        if (files.length === 1) {
          job.clickedFiles = true;
          // If ChatGPT invokes onShowFileChooser here, native directly passes
          // the already selected URI: no second Android picker.
          files[0].click();
        }
      }
    },
    tryDeliver(job) {
      if (this.state !== job || job.stage !== 'WAITING_INPUT') return;
      const found = this.findInput(job);
      if (found.error) {
        job.lastIssue = found.error;
        if (found.error === 'CHATGPT_FILE_INPUT_AMBIGUOUS') {
          this.report(job, found.error);
        } else this.exposeInput(job);
        return;
      }
      try {
        const transfer = new DataTransfer();
        transfer.items.add(job.file);
        found.input.files = transfer.files;
        if (!found.input.files || found.input.files.length !== 1 ||
            found.input.files[0].size !== job.file.size) {
          this.report(job, 'FILE_INPUT_REJECTED');
          return;
        }
        // These are actual events on ChatGPT's original input, not on a
        // synthetic/detached filename widget; ChatGPT owns the handler.
        found.input.dispatchEvent(new Event('input',
          {bubbles: true, composed: true}));
        found.input.dispatchEvent(new Event('change',
          {bubbles: true, composed: true}));
        this.report(job, 'INPUT_DISPATCHED');
      } catch (_) { this.report(job, 'FILE_INPUT_REJECTED'); }
    },
    commit(token, name, mime) {
      const job = this.state;
      if (!job || job.token !== token || job.stage !== 'LOADING')
        return 'TRANSFER_NOT_ACTIVE';
      try {
        if (typeof File !== 'function' || typeof DataTransfer !== 'function')
          return 'FILE_TRANSFER_API_UNAVAILABLE';
        job.file = new File(job.parts, name, {
          type: mime || 'application/octet-stream', lastModified: Date.now()
        });
        job.parts = null;
        job.stage = 'WAITING_INPUT';
        job.observer = new MutationObserver(() => this.tryDeliver(job));
        job.observer.observe(document.body,
          {childList: true, subtree: true, attributes: true});
        // An expiry reports a precise failure; no fixed delay before action.
        job.timer = setTimeout(() => {
          const reason = job.clickedFiles ?
            'FILE_CHOOSER_CALLBACK_NOT_INVOKED' : job.lastIssue;
          this.report(job, reason);
        }, 6500);
        this.tryDeliver(job);
        return this.last?.token === token ? this.last.code : 'WAITING_INPUT';
      } catch (_) {
        this.report(job, 'FILE_INPUT_REJECTED');
        return 'FILE_INPUT_REJECTED';
      }
    }
  };
  bridge.selectorRevision='web-v1.6.29';
  Object.defineProperty(window, key, {value: bridge, configurable: true});
  return 'READY';
})()
