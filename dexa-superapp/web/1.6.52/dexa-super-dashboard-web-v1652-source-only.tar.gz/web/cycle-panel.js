(() => {
  'use strict';
  const SETTINGS = 'dexa-cycle-panel-settings-v1';
  const AGENT = '__dexaCycleAgent160';
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();
  const levels = ['Instant', 'Medium', 'High', 'Extra High'];
  // User-specified one-click, text-only two-model multiplication qualification.
  // Neither message is sent until the owner explicitly presses Run.
  const DEMO_PROMPT = 'یک سؤال ریاضی ساده شامل فقط یک عملیات ضرب دو عدد صحیح مثبت یک‌رقمی طراحی کن. فقط خود سؤال را در یک خط دقیقاً به شکل «۷ × ۶ = ؟» بنویس. در ابتدا یا انتها هیچ توضیح، پاسخ یا عبارت دیگری ننویس.';
  const DEMO_WRAPPER = 'این سؤال را حل کن و جوابش را بده.';
  const initial = {first: 'Instant', second: 'Instant', mode: 'text', readAloud: false, wrapper: DEMO_WRAPPER};
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(SETTINGS) || '{}') || {}; } catch {}
  const state = {
    ...initial, ...saved, prompt: typeof saved.prompt==='string'?saved.prompt:DEMO_PROMPT, firstQuestion: '', output: '', validation: '', stage: 'READY',
    message: 'آمادهٔ دریافت پیام', error: '', running: false, cancelled: false, runId: '',
    audioDiagnostic: 'شنوندهٔ صوتی: هنوز آزمایشی انجام نشده است.'
  };
  if (!levels.includes(state.first)) state.first = 'Instant';
  if (!levels.includes(state.second)) state.second = 'Instant';
  state.mode = state.mode === 'voice' ? 'voice' : 'text';
  state.readAloud = typeof saved.readAloud === 'boolean' ? saved.readAloud : saved.voice === true;
  if (typeof state.wrapper !== 'string') state.wrapper = initial.wrapper;
  const sendStartedAt = [0,0];
  let audioTraceSeq=0;
  let audioEventCount=0;
  let manualProbeRunning=false, manualProbeToken=0;
  let audioTraceContext='',audioTraceContinuityLost=false;
  let cycleAudioPumpRunning=false,cycleAudioPumpToken=0;
  let cycleAudioPumpMode='',cycleAudioLastSnapshot='';
  let cycleAudioLastError='',cycleAudioSnapshotCount=0;
  let cycleAudioNativeComplete=false;
  let manualVoiceCandidateSeen=false,manualDiagnosticGapReported=false;
  let previousStage = '';

  function persist() {
    localStorage.setItem(SETTINGS, JSON.stringify({
      first: state.first, second: state.second, mode: state.mode, readAloud: state.readAloud, prompt: state.prompt, wrapper: state.wrapper
    }));
  }

  function stage(code, message, slot = 0, error = '') {
    state.stage = code; state.message = message; state.error = error;
    if (code !== previousStage) {
      previousStage = code;
      try { scriptStage(slot, 'CYCLE_' + code, error, undefined, state.runId); } catch {}
    }
    paint();
  }

  function paint() {
    const root = document.getElementById('dexaCyclePanel');
    if (!root) return;
    root.querySelector('[data-cycle-stage]').textContent = state.message +
      (state.error ? ' — ' + state.error : '');
    root.querySelector('[data-cycle-run]').disabled = state.running;
    const probeStart=root.querySelector('[data-audio-probe-start]');
    const probeStop=root.querySelector('[data-audio-probe-stop]');
    if(probeStart)probeStart.disabled=state.running||manualProbeRunning;
    if(probeStop)probeStop.disabled=!manualProbeRunning;
    root.querySelector('[data-cycle-cancel]').disabled = !state.running;
    root.querySelector('[data-cycle-output]').value = state.output;
    root.querySelector('[data-cycle-question]').value = state.firstQuestion;
    root.querySelector('[data-cycle-validation]').textContent = state.validation;
    const audioInfo=root.querySelector('[data-cycle-audio]');
    if(audioInfo)audioInfo.textContent=state.audioDiagnostic;
    const answerLabel = root.querySelector('[data-cycle-answer-label]');
    answerLabel.textContent = state.mode === 'voice' ? 'پاسخ چت صوتی مرورگر دوم' :
      state.readAloud ? 'پاسخ مرورگر دوم (همراه بلندخوانی)' : 'پاسخ متنی مرورگر دوم';
    const read = root.querySelector('#cycleReadAloud');
    if (read) {
      read.disabled = state.mode !== 'text';
      read.closest('label').classList.toggle('cycle-disabled', state.mode !== 'text');
    }
  }

  function mount() {
    const host = document.getElementById('boardContent');
    if (!host) return;
    if (host.querySelector('#dexaCyclePanel')) { paint(); return; }
    host.innerHTML =
      '<div id="dexaCyclePanel" class="cycle-panel">' +
      '<label class="cycle-label" for="cyclePrompt">پیام مرورگر اول</label>' +
      '<textarea id="cyclePrompt" class="cycle-field" rows="5" placeholder="پرامپت خود را اینجا بنویسید..."></textarea>' +
      '<div class="cycle-grid">' +
      '<label class="cycle-label">ایفورت مرورگر اول<select id="cycleFirst"></select></label>' +
      '<label class="cycle-label">ایفورت مرورگر دوم<select id="cycleSecond"></select></label>' +
      '</div>' +
      '<fieldset class="cycle-mode-group"><legend>حالت پاسخ مرورگر دوم</legend>' +
      '<label class="cycle-switch"><input type="radio" name="cycleResponseMode" value="text"><span>چت متنی</span></label>' +
      '<label class="cycle-switch cycle-mode-sub"><input id="cycleReadAloud" type="checkbox"><span>خواندن پاسخ نهایی با Read Aloud</span></label>' +
      '<label class="cycle-switch"><input type="radio" name="cycleResponseMode" value="voice"><span>چت صوتی (Voice Chat)</span></label></fieldset>' +
      '<label class="cycle-label" for="cycleWrapper">رپرِ پاسخ مرورگر اول</label>' +
      '<textarea id="cycleWrapper" class="cycle-field" rows="3" placeholder="متن دلخواه پیش از پاسخ مرورگر اول"></textarea>' +
      '<div class="row cycle-actions"><button class="primary" data-cycle-run>ارسال و اجرای چرخه</button>' +
      '<button data-cycle-cancel type="button" class="danger">توقف ادامهٔ چرخه</button></div>' +
      '<div class="notice" data-cycle-stage aria-live="polite"></div>' +
      '<div class="sub" data-cycle-audio aria-live="polite"></div>' +
      '<div class="row cycle-actions"><button type="button" data-audio-probe-start>شروع شنوندهٔ تشخیصی مرورگر دوم</button>' +
      '<button type="button" data-audio-probe-stop>توقف پایش تشخیصی</button></div>' +
      '<p class="sub">هنگام اجرای چرخه، پایش صوتی به‌طور خودکار از همان شروع ویس و مستقل از رسید ارسال فعال است. در بلندخوانی، موقعیت نسبی پخش و علت توقف نیز بدون ذخیرهٔ صوت یا متن ثبت می‌شود. دکمهٔ تشخیصی پایین فقط پایش دستیِ مرورگر دوم است و هیچ پیام یا فرمان حذفی نمی‌فرستد.</p>' +
      '<label class="cycle-label" for="cycleQuestion">سؤال واقعی ساخته‌شده در مرورگر اول</label>' +
      '<textarea id="cycleQuestion" data-cycle-question class="cycle-field" rows="2" readonly></textarea>' +
      '<label class="cycle-label" data-cycle-answer-label for="cycleOutput">پاسخ متنی مرورگر دوم</label>' +
      '<textarea id="cycleOutput" data-cycle-output class="cycle-field cycle-output" rows="7" readonly placeholder="پاسخ نهایی اینجا ظاهر می‌شود."></textarea>' +
      '<div class="notice" data-cycle-validation aria-live="polite"></div>' +
      '<p class="sub">با اجرای چرخه، چت‌های فعلی و پیش‌نویس‌های متنی هر دو مرورگر پاک می‌شوند. بعد از دریافت کامل پاسخ دوم، در حالت متنی ساده بلافاصله و در حالت صوتی فقط پس از اثبات پایان واقعی پخش یا گفتار، دو گفت‌وگوی همین چرخه حذف می‌شوند. انتظار برای پایان واقعی پاسخ یا صوت بدون مهلت زمانی ثابت ادامه دارد و با دکمهٔ توقف قابل لغو است. Voice Chat مستقل از Read Aloud است و در صورت نبود کادر ارسال متنی در Voice، اجرا با خطا متوقف می‌شود.</p>' +
      '</div>';
    const q = sel => host.querySelector(sel);
    for (const id of ['#cycleFirst', '#cycleSecond'])
      q(id).innerHTML = levels.map(x => '<option value="' + x + '">' +
        ({Instant:'اینستنت',Medium:'مدیوم',High:'های','Extra High':'اکسترا های'}[x]) +
        '</option>').join('');
    q('#cyclePrompt').value = state.prompt;
    q('#cycleWrapper').value = state.wrapper;
    q('#cycleFirst').value = state.first;
    q('#cycleSecond').value = state.second;
    for (const choice of host.querySelectorAll('input[name="cycleResponseMode"]'))
      choice.checked = choice.value === state.mode;
    q('#cycleReadAloud').checked = state.readAloud;
    q('#cyclePrompt').addEventListener('input', e => { state.prompt = e.target.value; persist(); });
    q('#cycleWrapper').addEventListener('input', e => { state.wrapper = e.target.value; persist(); });
    q('#cycleFirst').addEventListener('change', e => { state.first = e.target.value; persist(); });
    q('#cycleSecond').addEventListener('change', e => { state.second = e.target.value; persist(); });
    for (const choice of host.querySelectorAll('input[name="cycleResponseMode"]'))
      choice.addEventListener('change', e => {
        if (!e.target.checked) return;
        state.mode = e.target.value === 'voice' ? 'voice' : 'text';
        persist(); paint();
      });
    q('#cycleReadAloud').addEventListener('change', e => {
      if (state.mode !== 'text') return;
      state.readAloud = e.target.checked; persist(); paint();
    });
    q('[data-cycle-run]').onclick = () => { run().catch(() => {}); };
    q('[data-audio-probe-start]').onclick = () => { startManualProbe().catch(() => {}); };
    q('[data-audio-probe-stop]').onclick = () => { stopManualProbe(); };
    q('[data-cycle-cancel]').onclick = () => {
      state.cancelled = true;
      stage('CANCEL_REQUESTED',
        'توقف ثبت شد؛ ارسال انجام‌شده بازگردانده نمی‌شود.');
      // A manual Cancel also aborts waits for native bridge acknowledgments.
      // The original underlying command may still finish; do not replay it.
      if(typeof window.DexaCancelPendingNativeCalls==='function')
        window.DexaCancelPendingNativeCalls();
      for(const slot of [0,1]){
        void invokeOnce(slot,'stopPendingSend').catch(()=>{});
        void invokeOnce(slot,'voiceText','abort').catch(()=>{});
      }
    };
    paint();
  }

  // This is installed in the owner-authenticated ChatGPT WebView, never in a
  // server worker. It reads and operates on ordinary, owner-visible controls.
  // The dashboard only receives the two model answers it needs for the cycle.
  function installBrowserAgent() {
    const NAME = '__dexaCycleAgent160';
    if (location.hostname !== 'chatgpt.com') return {ok: false, error: 'NOT_CHATGPT'};
    if (window[NAME]?.revision === 'power-slider-v1652') return {ok: true, reused: true};
    const norm = s => String(s || '').replace(/\s+/g, ' ').trim();
    const vis = e => !!e && e.getClientRects().length > 0 &&
      getComputedStyle(e).visibility !== 'hidden';
    const all = selector => [...document.querySelectorAll(selector)].filter(vis);
    const label = e => [
      e.getAttribute('aria-label'), e.getAttribute('data-testid'),
      e.getAttribute('title'), e.textContent
    ].filter(Boolean).join(' ').trim();
    const ctrl = () => all('button,[role="button"]');
    const voiceExits = () => ctrl().filter(e =>
      /(exit|end|close|leave).{0,25}(voice|conversation|call)|(voice|conversation|call).{0,25}(exit|end|close|leave)|پایان مکالمه|خروج از مکالمه/i.test(label(e)));
    const isVoice = () => voiceExits().length === 1 || (
      ctrl().some(e => /mute|unmute|microphone|میکروفون/i.test(label(e))) &&
      ctrl().some(e => /voice|مکالمه/i.test(label(e))));
    const editor = () => {
      const a = all('textarea,[contenteditable="true"],[role="textbox"]')
        .filter(e => !e.closest('[aria-hidden="true"]') && !e.disabled);
      if (a.length === 1) return a[0];
      const preferred = a.filter(e => /^(type|ask chatgpt|message)$/i.test(
        (e.getAttribute('aria-label') || e.getAttribute('placeholder') || '').trim()));
      return preferred.length === 1 ? preferred[0] : null;
    };
    const value = e => e ? (e.isContentEditable ?
      (e.innerText || e.textContent || '') : (e.value || '')) : '';
    const erase = e => {
      e.focus();
      const sel = window.getSelection(), range = document.createRange();
      range.selectNodeContents(e); sel.removeAllRanges(); sel.addRange(range);
      document.execCommand('delete', false, null);
      return !norm(value(e));
    };
    const snapshot = () => {
      const e = editor();
      return {ok: true, path: location.pathname, editorReady: !!e,
        draftLength: e ? norm(value(e)).length : -1,
        voiceActive: isVoice(),
        voiceExitCount: voiceExits().length,
        connecting: /\bconnecting(\.{0,3})?\b/i.test((document.body.innerText || '').slice(-1500)),
        audibleMedia: all('audio,video').some(m => !m.paused)};
    };

    const voice = mode => {
      if (mode === 'text') {
        if (!isVoice()) return {ok: true, active: false};
        const exits = voiceExits();
        if (exits.length !== 1) return {ok: false, error: 'VOICE_EXIT_NOT_UNIQUE_' + exits.length};
        exits[0].click();
        return {ok: true, clicked: true};
      }
      if (mode === 'voice') {
        if (isVoice()) return {ok: true, active: true};
        const entries = ctrl().filter(e => /voice|گفتگوی صوتی|گفت‌وگوی صوتی/i.test(label(e)) &&
          !/read.aloud|voice-play|dictat|microphone|mute|stop|end|close|exit/i.test(label(e)));
        if (entries.length !== 1) return {ok: false, error: 'VOICE_ENTRY_NOT_UNIQUE_' + entries.length};
        entries[0].click();
        return {ok: true, clicked: true};
      }
      return {ok: false, error: 'INVALID_MODE'};
    };

    // Blind composition: write into the visible composer without inspecting
    // its old draft, comparing the inserted text or requiring an exact receipt.
    const compose = text => {
      const e=editor();
      if(!e)return {ok:false,error:'EDITOR_NOT_AVAILABLE'};
      e.focus();
      if(e.isContentEditable){
        const sel=window.getSelection(),range=document.createRange();
        range.selectNodeContents(e);sel.removeAllRanges();sel.addRange(range);
        document.execCommand('insertText',false,text);
      }else if(e.tagName==='TEXTAREA'){
        e.select();
        if(!document.execCommand('insertText',false,text)){
          e.setRangeText(text,0,e.textLength,'end');
          e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));
        }
      }
      return {ok:true,issued:true};
    };
    // Click the first enabled ChatGPT Send control once; do not verify draft.
    const send = () => {
      const buttons=ctrl().filter(b=>(
        /^(send-button|voice-send-button)$/i.test(b.getAttribute('data-testid')||'')||
        /^(send|send message|send prompt|ارسال|ارسال پیام)$/i.test(
          (b.getAttribute('aria-label')||b.getAttribute('title')||'').trim())
      )&&!b.disabled&&b.getAttribute('aria-disabled')!=='true');
      if(!buttons.length)return {ok:true,waiting:true};
      buttons[0].click();
      return {ok:true,clicked:true};
    };
    // Start exactly one local operation: compose, then click the original
    // Send control once it becomes enabled in THIS ChatGPT document.
    // A MutationObserver reports actual UI readiness, not a speculative delay.
    let sendJob = null;
    const sendStatus = () => sendJob ?
      {ok: true, stage: sendJob.stage, error: sendJob.error || ''} :
      {ok: true, stage: 'NONE'};
    const sendOnce = text => {
      if (sendJob && sendJob.stage === 'WAITING')
        return {ok: false, error: 'SEND_OPERATION_ALREADY_WAITING'};
      const job = {stage: 'WAITING', error: ''};
      sendJob = job;
      let composed=false,observer=null;
      const finish = (stage, error = '') => {
        if (job.stage !== 'WAITING') return;
        job.stage = stage; job.error = error;
        if (observer) observer.disconnect();
      };
      job.stop=()=>finish('ABORTED','ABORTED_BY_OWNER');
      const attempt = () => {
        if(job.stage!=='WAITING')return;
        if(!composed){
          // No error while a page is still rendering its editor; no URL check.
          if(!editor())return;
          const result=compose(text);
          if(!result.ok)return;
          composed=true;
        }
        const sent=send();
        if(sent.waiting)return;
        finish('CLICKED');
      };
      observer = new MutationObserver(attempt);
      observer.observe(document.body, {
        childList: true, subtree: true, attributes: true, characterData: true
      });
      queueMicrotask(attempt);
      return {ok: true, started: true};
    };
    const stopPendingSend = () => {
      if(!sendJob||sendJob.stage!=='WAITING')
        return {ok:true,aborted:false};
      // No Send click has happened; only discard the queued observer job.
      const j=sendJob;
      if(j.stop)j.stop('ABORTED_BY_OWNER');
      return {ok:true,aborted:j.stage==='ABORTED'};
    };
    const answer = () => {
      const page = document.body.innerText || '';
      const roleAnswers = all('[data-message-author-role="assistant"]');
      const last = roleAnswers.at(-1);
      const pos = page.lastIndexOf('ChatGPT said:');
      const suffix = pos >= 0 ? page.slice(pos + 'ChatGPT said:'.length) : '';
      const roleText = last ? (last.innerText || last.textContent || '').trim() : '';
      const text = roleText || suffix.split('Response complete')[0]
        .split('Is this conversation helpful so far?')[0]
        .split('ChatGPT can make mistakes.')[0].trim();
      const busy = !!document.querySelector(
        '[data-testid="stop-button"],button[aria-label*="Stop generating"],button[aria-label*="Stop response"]');
      const explicitCompleted=suffix.includes('Response complete');
      const completed=explicitCompleted||(roleAnswers.length>0&&!busy);
      return {ok:true,path:location.pathname,completed,explicitCompleted,busy,
        hasUser: all('[data-message-author-role="user"]').length > 0 || page.includes('You said:'),
        answer: String(text).slice(0, 120000)};
    };
    // DEXA 1.6.45: passive audio diagnostics in the authenticated ChatGPT page.
    // Only event classes, counts and coarse player states leave the WebView.
    // No audio samples, transcripts, media URLs, arbitrary element labels,
    // streams, keys, tokens or personal content are collected.
    let audioProbe=null, audioProbeSerial=0;
    const seenMedia=new WeakSet(), seenNodes=new WeakSet(), seenContexts=new WeakSet();
    const diagnosticContext=()=>Math.round(performance.timeOrigin||0);
    const recordAudio=(code,count=0)=>{
      const p=audioProbe;
      if(!p)return;
      // Browser voice streams may use 50+ tiny buffers per second. Counters
      // keep exact totals; exported trace samples first and each 25th chunk.
      if((code==='WA_BUFFER_START'||code==='WA_BUFFER_ENDED')&&
          count!==1&&count%25!==0)return;
      const row={seq:++p.seq,code,time:Date.now(),count:Math.min(5000,Math.max(0,count|0))};
      p.events.push(row);
      if(p.events.length>180){p.events.shift();p.dropped++;}
    };
    const mediaProgress=(media,p,kind)=>{
      const d=Number(media?.duration),t=Number(media?.currentTime);
      if(!Number.isFinite(d)||d<=0||!Number.isFinite(t)){
        if(kind==='PAUSE'||kind==='UI_READY')recordAudio('HTML_'+kind+'_POSITION_UNKNOWN');
        return {known:false,pct:-1};
      }
      const pct=Math.max(0,Math.min(100,Math.round(t/d*100)));
      p.lastMediaPct=Math.max(p.lastMediaPct,pct);
      if(kind==='TIME'){
        const bucket=Math.floor(pct/25);
        if(bucket>p.lastProgressBucket){
          p.lastProgressBucket=bucket;
          recordAudio('HTML_PLAY_PROGRESS_PCT',Math.min(100,bucket*25));
        }
      }else{
        recordAudio('HTML_'+kind+'_POSITION_PCT',pct);
        if(kind==='PAUSE'){
          recordAudio(media.ended?'HTML_PAUSE_MEDIA_ENDED':'HTML_PAUSE_MEDIA_NOT_ENDED');
          recordAudio(media.seeking?'HTML_PAUSE_SEEKING':'HTML_PAUSE_NOT_SEEKING');
        }
      }
      return {known:true,pct};
    };
    const mediaEvent=(event)=>{
      const p=audioProbe,media=event.currentTarget;
      if(!p||!(media instanceof HTMLMediaElement)||media.tagName!=='AUDIO')return;
      if(event.type==='playing'){
        p.activeHtmlAudio.add(media);
        if(p.mode==='voice'&&p.turnMarked){
          p.voiceMediaStarts++;
          p.voiceMediaEnded.delete(media);
          p.voicePossibleEnd=false;p.voiceSilentSamples=0;
          recordAudio('VOICE_HTML_SEGMENT_START',p.voiceMediaStarts);
        }
        if(p.primaryMedia&&p.primaryMedia!==media&&p.mode==='read-aloud')
          p.ambiguous=true;
        p.primaryMedia=media;p.htmlStarted++;p.htmlPlaying=true;
        p.htmlPauseNaturalEnd=false;
        p.lastProgressBucket=-1;
        recordAudio('HTML_PLAYING',p.htmlStarted);
        mediaProgress(media,p,'TIME');
      }else if(event.type==='ended'&&media.ended===true){
        p.activeHtmlAudio.delete(media);
        if(p.mode==='voice'&&p.turnMarked&&!p.voiceMediaEnded.has(media)){
          p.voiceMediaEnded.add(media);p.voiceMediaNaturalEnds++;
          recordAudio('VOICE_HTML_NATURAL_SEGMENT_END',p.voiceMediaNaturalEnds);
        }
        if(media!==p.primaryMedia){
          recordAudio('HTML_OTHER_SEGMENT_ENDED');
          return;
        }
        p.htmlEnded++;p.htmlPlaying=false;
        recordAudio('HTML_ENDED',p.htmlEnded);
      }else if(event.type==='pause'){
        p.activeHtmlAudio.delete(media);
        if(media.ended===true){
          if(media===p.primaryMedia&&p.mode==='read-aloud'){
            p.htmlPauseNaturalEnd=true;
            recordAudio('HTML_NATURAL_END_STATE_ON_PAUSE');
          }
          if(p.mode==='voice'&&p.turnMarked&&!p.voiceMediaEnded.has(media)){
            p.voiceMediaEnded.add(media);p.voiceMediaNaturalEnds++;
            recordAudio('VOICE_HTML_NATURAL_SEGMENT_END',p.voiceMediaNaturalEnds);
          }
        }
        if(media!==p.primaryMedia)return;
        p.htmlPlaying=false;p.htmlPaused++;
        recordAudio('HTML_PAUSED',p.htmlPaused);
        mediaProgress(media,p,'PAUSE');
      }else if(media===p.primaryMedia&&event.type==='waiting'){
        recordAudio('HTML_WAITING');
      }else if(media===p.primaryMedia&&event.type==='timeupdate'){
        mediaProgress(media,p,'TIME');
      }else if(media===p.primaryMedia&&event.type==='durationchange'){
        const duration=media.duration;
        recordAudio(Number.isFinite(duration)&&duration>0?
          'HTML_DURATION_FINITE':'HTML_DURATION_STREAM_OR_UNKNOWN');
      }else if(media===p.primaryMedia&&event.type==='emptied'){
        recordAudio('HTML_MEDIA_EMPTIED');
      }else if(media===p.primaryMedia&&event.type==='abort'){
        recordAudio('HTML_MEDIA_ABORT');
      }else if(event.type==='error'){
        p.errors++;recordAudio('HTML_ERROR');
      }
    };
    const attachMedia=media=>{
      if(!(media instanceof HTMLMediaElement)||media.tagName!=='AUDIO'||
          seenMedia.has(media))return;
      seenMedia.add(media);
      for(const type of ['playing','pause','ended','waiting','error',
                         'timeupdate','durationchange','emptied','abort'])
        media.addEventListener(type,mediaEvent);
    };
    const playbackUi=()=>{
      const names=all('button,[role="button"]').map(e=>
        [e.getAttribute('aria-label'),e.getAttribute('title'),
         e.getAttribute('data-testid')].filter(Boolean).join(' ').toLowerCase());
      const count=re=>names.filter(x=>re.test(x)).length;
      const live=all('[aria-live],[role="status"]').map(e=>
        // Classify a small fixed vocabulary without exporting its contents.
        norm((e.getAttribute('aria-label')||e.textContent||'').slice(0,70)).toLowerCase());
      return {
        ready:count(/(?:^|\s)read[ -]?aloud(?:\s|$)/i),
        pause:count(/pause(?:\s+(?:reading|audio|playback))?/i),
        stop:count(/stop\s+(?:reading|audio|playback|speaking)/i),
        resume:count(/resume\s+(?:reading|audio|playback)/i),
        voiceSpeaking:count(/(?:^|\s)(?:speaking|interrupt voice|stop speaking)(?:\s|$)/i)+
          live.filter(x=>/^(?:speaking|chatgpt is speaking|در حال صحبت)$/.test(x)).length,
        voiceListening:count(/(?:^|\s)(?:listening|waiting for voice|ready to listen)(?:\s|$)/i)+
          live.filter(x=>/^(?:listening|ready to listen|در حال گوش دادن)$/.test(x)).length,
        voiceActive:isVoice(),
        exitVisible:count(/(?:end voice|exit voice|leave voice|close voice|پایان مکالمه|خروج از ویس)/i),
        mutedVisible:count(/(?:unmute microphone|turn on microphone|enable microphone|وصل میکروفون|باز کردن میکروفون)/i)
      };
    };
    const inspectPlaybackUi=()=>{
      const p=audioProbe;
      if(!p)return;
      const u=playbackUi();
      if(!p.ui||p.ui.voiceActive!==u.voiceActive){
        if(u.voiceActive){
          p.voiceSessionNumber++;
          p.voiceEnergyEver=false;
          p.voiceSilentSamples=0;
          p.voicePossibleEnd=false;
          p.voiceSpeechState='WAIT_FOR_RECEIVED_AUDIO';
          p.rtcPrevious.clear();
          recordAudio('RTC_VOICE_SESSION_ACTIVE',p.voiceSessionNumber);
        }else{
          p.voicePossibleEnd=false;
          p.voiceSilentSamples=0;
          p.voiceSpeechState='VOICE_SESSION_CLOSED';
          recordAudio('RTC_VOICE_SESSION_CLOSED');
        }
        recordAudio(u.voiceActive?'VOICE_UI_ACTIVE':'VOICE_UI_INACTIVE');
      }
      if(!p.ui||!!p.ui.exitVisible!==!!u.exitVisible)
        recordAudio(u.exitVisible?'VOICE_END_BUTTON_VISIBLE':'VOICE_END_BUTTON_ABSENT');
      if(!p.ui||!!p.ui.mutedVisible!==!!u.mutedVisible)
        recordAudio(u.mutedVisible?'VOICE_MIC_MUTED_UI':'VOICE_MIC_NOT_MUTED_UI');
      if(u.pause||u.stop){
        if(!p.uiActive){p.uiActive=true;recordAudio('UI_PLAYBACK_ACTIVE');}
      }
      if(p.uiActive&&!u.pause&&!u.stop&&u.ready){
        if(!p.uiReturned){
          p.uiReturned=true;
          recordAudio('UI_READ_ALOUD_READY_RETURNED');
          if(p.primaryMedia)mediaProgress(p.primaryMedia,p,'UI_READY');
          if(p.lastMediaPct>=0)
            recordAudio('HTML_LAST_OBSERVED_PCT',p.lastMediaPct);
        }
      }
      if(u.voiceSpeaking&&!p.voiceSpoke){
        p.voiceSpoke=true;recordAudio('UI_VOICE_SPEAKING');
      }
      if(p.voiceSpoke&&u.voiceListening&&!u.voiceSpeaking&&!p.voiceListeningAfterSpeech){
        p.voiceListeningAfterSpeech=true;recordAudio('UI_VOICE_LISTENING_AFTER_SPEECH');
      }
      p.ui=u;
      for(const media of document.querySelectorAll('audio'))attachMedia(media);
    };
    const uiClicked=event=>{
      const p=audioProbe;
      if(!p||!event.isTrusted)return;
      const b=event.target?.closest?.('button,[role="button"]');
      if(!b)return;
      const name=[b.getAttribute('aria-label'),b.getAttribute('title'),
        b.getAttribute('data-testid')].filter(Boolean).join(' ').toLowerCase();
      if(p.mode==='read-aloud'&&p.uiActive)
        recordAudio('UI_TRUSTED_CLICK_WHILE_PLAYING');
      if(p.mode==='read-aloud'&&
        /(?:stop\s+(?:reading|audio|playback)|pause\s+(?:reading|audio|playback))/.test(name)){
        p.userInterrupted=true;recordAudio('UI_USER_STOP_OR_PAUSE');
      }
    };
    document.addEventListener('click',uiClicked,true);
    document.addEventListener('visibilitychange',()=>{
      if(audioProbe)recordAudio(document.hidden?'PAGE_VISIBILITY_HIDDEN':'PAGE_VISIBILITY_VISIBLE');
    });
    let uiObserver=null,uiPending=false;
    const onUiChange=()=>{
      if(!audioProbe||uiPending)return;
      uiPending=true;
      setTimeout(()=>{uiPending=false;try{inspectPlaybackUi();}catch{}},100);
    };
    const attachUiObserver=()=>{
      if(uiObserver||!document.body)return;
      uiObserver=new MutationObserver(onUiChange);
      uiObserver.observe(document.body,{subtree:true,childList:true,
        attributes:true,attributeFilter:['aria-label','title','data-testid']});
    };
    // Observe detached audio elements too. Native method return values and
    // exceptions are preserved. Never intercept or copy audio buffers.
    const mediaPlay=HTMLMediaElement.prototype.play;
    try{
      HTMLMediaElement.prototype.play=function(...args){
        attachMedia(this);
        if(audioProbe&&this.tagName==='AUDIO')recordAudio('HTML_PLAY_CALLED');
        return mediaPlay.apply(this,args);
      };
    }catch{}
    // WebAudio may stream many chunks. ended is an individual source end,
    // NOT a complete assistant response and NEVER an independent delete gate.
    const watchAudioBufferStart=node=>{
      const p=audioProbe;
      if(!p||!window.AudioBufferSourceNode||
          !(node instanceof AudioBufferSourceNode)||seenNodes.has(node))return;
      seenNodes.add(node);p.waStarted++;
      if(p.mode==='voice'&&p.turnMarked){
        p.voicePossibleEnd=false;p.voiceSilentSamples=0;
      }
      recordAudio('WA_BUFFER_START',p.waStarted);
      try{
        node.addEventListener('ended',()=>{
          if(audioProbe!==p)return;
          p.waEnded++;recordAudio('WA_BUFFER_ENDED',p.waEnded);
        },{once:true});
      }catch{p.errors++;recordAudio('WA_LISTENER_ERROR');}
      const context=node.context;
      if(context&&!seenContexts.has(context)){
        seenContexts.add(context);
        try{context.addEventListener('statechange',()=>{
          if(!audioProbe)return;
          recordAudio(context.state==='running'?'WA_CONTEXT_RUNNING':
            context.state==='suspended'?'WA_CONTEXT_SUSPENDED':'WA_CONTEXT_CLOSED');
        });}catch{}
      }
    };
    const instrumentAudioStart=proto=>{
      if(!proto||typeof proto.start!=='function')return;
      const start=proto.start;
      try{
        proto.start=function(...args){
          const r=start.apply(this,args);
          watchAudioBufferStart(this);
          return r;
        };
      }catch{}
    };
    // Chrome supplies its own AudioBufferSourceNode.start override, so
    // hooking only AudioScheduledSourceNode.start misses actual sources.
    instrumentAudioStart(window.AudioScheduledSourceNode?.prototype);
    if(window.AudioBufferSourceNode?.prototype!==window.AudioScheduledSourceNode?.prototype)
      instrumentAudioStart(window.AudioBufferSourceNode?.prototype);
    const ctxProto=window.AudioContext?.prototype;
    if(ctxProto&&typeof ctxProto.createMediaStreamSource==='function'){
      const originalCreate=ctxProto.createMediaStreamSource;
      try{
        ctxProto.createMediaStreamSource=function(...args){
          const result=originalCreate.apply(this,args);
          if(audioProbe){audioProbe.waStreamSources++;recordAudio('WA_STREAM_SOURCE');}
          return result;
        };
      }catch{}
    }
    // SpeechSynthesis is a distinct possible playback path.
    const speakProto=window.SpeechSynthesis?.prototype;
    if(speakProto&&typeof speakProto.speak==='function'){
      const originalSpeak=speakProto.speak;
      try{
        speakProto.speak=function(utterance){
          if(audioProbe&&utterance?.addEventListener){
            const p=audioProbe;
            p.ttsQueued++;recordAudio('TTS_QUEUED',p.ttsQueued);
            utterance.addEventListener('start',()=>{
              if(audioProbe!==p)return;
              p.ttsStarted++;recordAudio('TTS_STARTED',p.ttsStarted);
            },{once:true});
            utterance.addEventListener('end',()=>{
              if(audioProbe!==p)return;
              p.ttsEnded++;recordAudio('TTS_ENDED',p.ttsEnded);
            },{once:true});
            utterance.addEventListener('error',()=>{
              if(audioProbe!==p)return;
              p.errors++;recordAudio('TTS_ERROR');
            },{once:true});
          }
          return originalSpeak.apply(this,arguments);
        };
      }catch{}
    }
    // A WebRTC audio receiver can stay live while the assistant is silent.
    // Capture track lifecycle metadata only; never sample incoming audio.
    const rtcProto=window.RTCPeerConnection?.prototype;
    const seenPeers=new WeakSet(),seenTracks=new WeakSet();
    if(rtcProto&&typeof rtcProto.setRemoteDescription==='function'){
      const originalRemote=rtcProto.setRemoteDescription;
      try{
        rtcProto.setRemoteDescription=function(...args){
          const p=audioProbe;
          if(p&&!p.rtcPeers.includes(this)){
            p.rtcPeers.push(this);
            recordAudio('RTC_PEER_OBSERVED',p.rtcPeers.length);
          }
          if(!seenPeers.has(this)){
            seenPeers.add(this);
            this.addEventListener('track',event=>{
              const track=event.track;
              if(!track||track.kind!=='audio'||seenTracks.has(track))return;
              seenTracks.add(track);
              const p=audioProbe;if(!p)return;
              p.rtcTracks.push(track);
              recordAudio('RTC_AUDIO_TRACK',p.rtcTracks.length);
              track.addEventListener('mute',()=>{
                if(audioProbe===p)recordAudio('RTC_AUDIO_MUTED');
              });
              track.addEventListener('unmute',()=>{
                if(audioProbe===p)recordAudio('RTC_AUDIO_UNMUTED');
              });
              track.addEventListener('ended',()=>{
                if(audioProbe===p)recordAudio('RTC_AUDIO_TRACK_ENDED');
              });
            });
          }
          return originalRemote.apply(this,args);
        };
      }catch{}
    }
    // Diagnostic-only Voice speech phase. Continued incoming packets with
    // unchanged cumulative audio energy are silence *within an open Voice
    // session*. Packet loss, missing stats and absent tracks mean UNKNOWN,
    // never silence. Three positive packet-flow observations are only a
    // revocable candidate, never authorization to stop Voice or delete chats.
    const setSpeechPhase=(p,phase,code)=>{
      if(p.voiceSpeechState===phase)return;
      p.voiceSpeechState=phase;
      if(code)recordAudio(code);
    };
    const sampleRtcStats=()=>{
      const p=audioProbe;
      if(!p||!p.rtcPeers.length||p.statsPending||
         Date.now()-p.statsAt<1200)return;
      p.statsPending=true;p.statsAt=Date.now();
      const peers=p.rtcPeers.slice(0,4);
      Promise.allSettled(peers.map(pc=>pc.getStats())).then(results=>{
        if(audioProbe!==p)return;
        let inbound=0,packetsDelta=0,energyDelta=0,energyKnown=true;
        let samplesDurationDelta=0,samplesDurationKnown=true;
        let havePrior=false,packetReset=false,hasFailed=false;
        const used=new Set();
        for(let i=0;i<results.length;i++){
          const row=results[i];
          if(row.status!=='fulfilled'){hasFailed=true;continue;}
          for(const value of row.value.values()){
            if(value?.type!=='inbound-rtp'||
               (value.kind!=='audio'&&value.mediaType!=='audio'))continue;
            inbound++;
            // Keyed in memory only; NEVER export peer/SSRC/track IDs.
            const key=i+':'+String(value.id);
            used.add(key);
            const packets=Number(value.packetsReceived);
            const energy=Number(value.totalAudioEnergy);
            const validPackets=Number.isFinite(packets)&&packets>=0;
            const validEnergy=Number.isFinite(energy)&&energy>=0;
            const samplesDuration=Number(value.totalSamplesDuration);
            const validSamplesDuration=Number.isFinite(samplesDuration)&&
              samplesDuration>=0&&value.totalSamplesDuration!=null;
            const previous=p.rtcPrevious.get(key);
            if(previous){
              havePrior=true;
              if(!validPackets||packets<previous.packets){
                packetReset=true;
              }else packetsDelta+=packets-previous.packets;
              if(!validEnergy||!previous.energyKnown||energy<previous.energy){
                energyKnown=false;
              }else energyDelta+=energy-previous.energy;
              if(!validSamplesDuration||!previous.durationKnown||
                  samplesDuration<previous.samplesDuration){
                samplesDurationKnown=false;
              }else samplesDurationDelta+=samplesDuration-previous.samplesDuration;
            }else {energyKnown=false;samplesDurationKnown=false;}
            if(validPackets)
              p.rtcPrevious.set(key,{packets,energy,energyKnown:validEnergy,
                samplesDuration,durationKnown:validSamplesDuration});
          }
        }
        for(const key of [...p.rtcPrevious.keys()])
          if(!used.has(key))p.rtcPrevious.delete(key);
        if(inbound&&!p.rtcStatsEver){
          p.rtcStatsEver=true;
          recordAudio('RTC_INBOUND_AUDIO_STATS_AVAILABLE',inbound);
        }
        let state;
        if(!inbound){
          state='NO_INBOUND_AUDIO';
        }else if(hasFailed||packetReset||!havePrior){
          state='UNKNOWN_OR_NEW_STREAM';
        }else if(packetsDelta<=0){
          state='NO_PACKET_CHANGE';
        }else if(!energyKnown){
          state='PACKETS_ENERGY_UNKNOWN';
        }else{
          state=energyDelta>0?'PACKETS_WITH_ENERGY':'PACKETS_NO_ENERGY';
          // Calibrate only against the current outgoing Voice turn.
          // An energy level close to zero but not literally zero can be an
          // always-on WebRTC receiver's silence/noise floor. A quiet sample
          // stays revocable and cannot authorize an end by itself.
          if(state==='PACKETS_WITH_ENERGY'&&samplesDurationKnown&&
              samplesDurationDelta>0){
            const level=Math.sqrt(Math.max(0,energyDelta/samplesDurationDelta));
            if(Number.isFinite(level)){
              p.voicePeakLevel=Math.max(p.voicePeakLevel,level);
              if(p.voicePeakLevel>=0.008&&
                  level<Math.min(0.008,p.voicePeakLevel*0.075))
                state='PACKETS_LOW_ENERGY';
            }
          }
        }
        if(state!==p.rtcObservation){
          p.rtcObservation=state;
          recordAudio('RTC_'+state);
        }
        if(!p.ui?.voiceActive||p.mode!=='voice')return;
        const activeAudio=p.activeHtmlAudio.size>0;
        if(state==='PACKETS_WITH_ENERGY'){
          p.voiceEnergyEver=true;
          p.voiceSilentSamples=0;
          const wasCandidate=p.voicePossibleEnd;
          p.voicePossibleEnd=false;
          setSpeechPhase(p,'SPEECH_ENERGY_DETECTED',
            wasCandidate?'RTC_SPEECH_RESUMED_AFTER_CANDIDATE':
            'RTC_SPEECH_ENERGY_DETECTED');
        }else if((state==='PACKETS_NO_ENERGY'||
                    state==='PACKETS_LOW_ENERGY')&&p.voiceEnergyEver){
          if(activeAudio){
            p.voiceSilentSamples=0;
            p.voicePossibleEnd=false;
            setSpeechPhase(p,'HTML_AUDIO_STILL_PLAYING',
              'RTC_SILENCE_BUT_HTML_PLAYING');
          }else{
            p.voiceSilentSamples=Math.min(3,p.voiceSilentSamples+1);
            if(p.voiceSilentSamples===1)
              setSpeechPhase(p,'SILENT_PACKETS_1','RTC_SILENT_PACKETS_1');
            else if(p.voiceSilentSamples===2)
              setSpeechPhase(p,'SILENT_PACKETS_2','RTC_SILENT_PACKETS_2');
            else if(p.voiceSilentSamples===3&&!p.voicePossibleEnd){
              p.voicePossibleEnd=true;
              p.voiceCandidates++;
              setSpeechPhase(p,'POSSIBLE_END_SPEECH',
                'RTC_POSSIBLE_SPEECH_END');
            }
          }
        }else{
          // An outage is NOT zero-energy audio. Revoke any prior candidate.
          if(p.voicePossibleEnd)recordAudio('RTC_CANDIDATE_REVOKED_FLOW_GAP');
          p.voicePossibleEnd=false;
          p.voiceSilentSamples=0;
          setSpeechPhase(p,state==='NO_PACKET_CHANGE'?
            'PACKET_FLOW_STOPPED_UNKNOWN':'NO_USABLE_AUDIO_STATS',
            state==='NO_PACKET_CHANGE'?
              'RTC_FLOW_GAP_NOT_SPEECH_END':'RTC_AUDIO_EVIDENCE_UNKNOWN');
        }
      }).catch(()=>{
        if(audioProbe!==p)return;
        p.voicePossibleEnd=false;
        p.voiceSilentSamples=0;
        setSpeechPhase(p,'STATS_ERROR_UNKNOWN','RTC_STATS_ERROR');
      }).finally(()=>{p.statsPending=false;});
    };
    const audioMonitor=(action,mode)=>{
      if(action==='arm'){
        if(mode!=='read-aloud'&&mode!=='voice')
          return {ok:false,error:'AUDIO_MODE_INVALID'};
        audioProbe={
          mode,probeId:++audioProbeSerial,seq:0,events:[],dropped:0,
          rtcTracks:[],rtcPeers:[],rtcObservation:'UNKNOWN',
          rtcPrevious:new Map(),activeHtmlAudio:new Set(),statsPending:false,statsAt:0,
          rtcStatsEver:false,
          voiceSessionNumber:0,voiceEnergyEver:false,voiceSilentSamples:0,
          voicePossibleEnd:false,voiceCandidates:0,voicePeakLevel:0,
          voiceMediaStarts:0,voiceMediaNaturalEnds:0,
          voiceMediaEnded:new WeakSet(),
          voiceSpeechState:'WAIT_FOR_RECEIVED_AUDIO',
          htmlStarted:0,htmlEnded:0,
          htmlPaused:0,htmlPauseNaturalEnd:false,
          htmlPlaying:false,primaryMedia:null,ambiguous:false,
          waStarted:0,waEnded:0,waStreamSources:0,ttsQueued:0,
          ttsStarted:0,ttsEnded:0,errors:0,userInterrupted:false,
          lost:false,uiActive:false,uiReturned:false,voiceSpoke:false,
          voiceListeningAfterSpeech:false,lastMediaPct:-1,
          lastProgressBucket:-1,turnMarked:false,ui:null
        };
        attachUiObserver();
        try{inspectPlaybackUi();}catch{}
        recordAudio('PROBE_ARMED');
        recordAudio(window.AudioScheduledSourceNode?'WEB_AUDIO_HOOK_AVAILABLE':'WEB_AUDIO_HOOK_UNAVAILABLE');
        return {ok:true,armed:true,mode,pageEpoch:diagnosticContext(),
          probeId:audioProbe.probeId};
      }
      if(action==='mark'){
        if(!audioProbe){
          const armed=audioMonitor('arm',mode==='voice'?'voice':'read-aloud');
          if(!armed.ok)return armed;
          recordAudio('PROBE_ARMED_LATE_AT_SEND');
        }
        const x=audioProbe;
        if(!x.turnMarked){
          x.turnMarked=true;x.voiceSpoke=false;x.voiceListeningAfterSpeech=false;
          x.voiceEnergyEver=false;x.voicePeakLevel=0;
          x.voicePossibleEnd=false;x.voiceSilentSamples=0;
          x.voiceMediaStarts=0;x.voiceMediaNaturalEnds=0;
          x.voiceMediaEnded=new WeakSet();
          x.turnStart={html:x.htmlStarted,wa:x.waStarted,tts:x.ttsStarted};
          recordAudio('VOICE_TURN_SEND_MARKED');
        }
        return {ok:true,marked:true,pageEpoch:diagnosticContext(),
          probeId:x.probeId};
      }
      if(action==='events'){
        const p=audioProbe;
        if(!p)return {ok:true,stage:'UNARMED',events:[]};
        const since=Number.isSafeInteger(mode)&&mode>=0?mode:0;
        if(p.events.length&&since<p.events[0].seq-1)p.lost=true;
        return {ok:true,mode:p.mode,dropped:p.dropped,lost:p.lost,seq:p.seq,
          pageEpoch:diagnosticContext(),probeId:p.probeId,
          events:p.events.filter(x=>x.seq>since).slice(0,40)};
      }
      if(action==='status'){
        const p=audioProbe;
        if(!p)return {ok:true,stage:'UNARMED'};
        try{inspectPlaybackUi();}catch{}
        sampleRtcStats();
        const ui=p.ui||playbackUi();
        const htmlDone=p.htmlStarted===1&&
          (p.htmlEnded===1||p.htmlPauseNaturalEnd)&&!p.htmlPlaying;
        const ttsDone=p.ttsStarted===1&&p.ttsEnded===1;
        const allWebAudioChunksEnded=p.waStarted>0&&p.waEnded===p.waStarted;
        const blocked=p.ambiguous||p.userInterrupted||p.errors>0||p.lost;
        const sourceStarted=p.htmlStarted>0||p.waStarted>0||p.ttsStarted>0;
        // Correlate an explicit ChatGPT UI transition with playback
        // completion; one WebAudio chunk ending alone never proves a turn.
        const playerFinished=p.uiActive&&p.uiReturned&&
          !ui.pause&&!ui.stop;
        const webAudioPlayerEnd=playerFinished&&allWebAudioChunksEnded;
        const turn=p.turnStart||{html:0,wa:0,tts:0};
        const voiceAudioAfterSend=(p.waStarted>turn.wa&&allWebAudioChunksEnded)||
          (p.htmlStarted>turn.html&&htmlDone)||
          (p.ttsStarted>turn.tts&&ttsDone);
        const voiceTurnEnd=p.turnMarked&&p.voiceSpoke&&
          p.voiceListeningAfterSpeech&&voiceAudioAfterSend;
        // Voice can remain on and listening after speech. Its answer may
        // contain multiple HTML audio segments. A natural end of EVERY
        // observed post-Send segment plus a revocable in-band RTP quiet
        // candidate is independent of closing the voice session. It is
        // corroborated by a fresh native model response-complete event in
        // the dashboard BEFORE any Voice OFF operation.
        const voiceAllNaturalSegments=p.turnMarked&&p.voiceMediaStarts>0&&
          p.voiceMediaNaturalEnds===p.voiceMediaStarts&&
          p.activeHtmlAudio.size===0;
        const noOngoingAuxiliaryAudio=(p.waStarted<=turn.wa||
          p.waEnded===p.waStarted)&&
          (p.ttsStarted<=turn.tts||p.ttsEnded===p.ttsStarted);
        const voiceQuietComposite=voiceAllNaturalSegments&&
          noOngoingAuxiliaryAudio&&p.voiceEnergyEver&&
          p.voicePossibleEnd&&ui.voiceActive&&ui.mutedVisible===1;
        const voiceConfirmed=(voiceTurnEnd&&p.activeHtmlAudio.size===0&&
          noOngoingAuxiliaryAudio)||voiceQuietComposite;
        let evidence='';
        if(!blocked){
          if(p.mode==='read-aloud'&&playerFinished){
            if(htmlDone)evidence=p.htmlEnded===1?
              'HTML_MEDIA_NATURAL_ENDED_AND_PLAYER_READY':
              'HTML_MEDIA_ENDED_STATE_AND_PLAYER_READY';
            else if(ttsDone)evidence='SPEECH_SYNTHESIS_ENDED_AND_PLAYER_READY';
            else if(webAudioPlayerEnd)evidence='WEB_AUDIO_CHUNKS_ENDED_AND_PLAYER_READY';
          }else if(voiceConfirmed){
            evidence=voiceTurnEnd?'VOICE_SPEAKING_TO_LISTENING_WITH_AUDIO_END':
              'VOICE_NATURAL_SEGMENTS_AND_QUIET_RTP';
          }
        }
        const stage=blocked?'AMBIGUOUS':evidence?'ENDED':
          sourceStarted?'ACTIVE_OR_INDETERMINATE':'ARMED_NO_AUDIO_EVIDENCE';
        return {ok:true,mode:p.mode,stage,evidence,
          started:sourceStarted,seq:p.seq,dropped:p.dropped,lost:p.lost,
          pageEpoch:diagnosticContext(),probeId:p.probeId,turnMarked:p.turnMarked,
          htmlStarted:p.htmlStarted,htmlEnded:p.htmlEnded,
          htmlPauseNaturalEnd:p.htmlPauseNaturalEnd,
          voiceMediaStarts:p.voiceMediaStarts,
          voiceMediaNaturalEnds:p.voiceMediaNaturalEnds,
          voiceAllNaturalSegments,
          webAudioStarted:p.waStarted,webAudioEnded:p.waEnded,
          webAudioStreamSources:p.waStreamSources,
          speechStarted:p.ttsStarted,speechEnded:p.ttsEnded,
          rtcAudioTracks:p.rtcTracks.length,rtcPeers:p.rtcPeers.length,
          rtcObservation:p.rtcObservation,
          voiceSpeechState:p.voiceSpeechState,
          voiceEnergySeen:p.voiceEnergyEver,
          voicePossibleEnd:p.voicePossibleEnd,
          voicePeakCalibrated:p.voicePeakLevel>=0.008,
          voiceSilentPacketSamples:p.voiceSilentSamples,
          voiceCandidateCount:p.voiceCandidates,
          htmlActiveSegments:p.activeHtmlAudio.size,
          rtcLiveTracks:p.rtcTracks.filter(t=>t.readyState==='live').length,
          rtcMutedTracks:p.rtcTracks.filter(t=>t.muted).length,
          contextHint:typeof window.AudioContext==='function',
          playerActive:p.uiActive,playerReturned:p.uiReturned,
          voiceSpoke:p.voiceSpoke,voiceListeningAfterSpeech:p.voiceListeningAfterSpeech,
          voiceActive:ui.voiceActive,voiceExitVisible:ui.exitVisible,
          voiceMicMutedVisible:ui.mutedVisible,
          htmlLastPercent:p.lastMediaPct,
          htmlPaused:p.htmlPaused,htmlPlaying:p.htmlPlaying,
          playerReady:ui.ready,playerPause:ui.pause,playerStop:ui.stop,
          interrupted:p.userInterrupted,errors:p.errors};
      }
      return {ok:false,error:'AUDIO_ACTION_INVALID'};
    };

    // The actual Voice controls are in a different row from the composer.
    // Real owner telemetry (Nov 9, slots 0+1) showed the same first
    // button-path for mute/unmute, and a distinct second button for End Voice.
    // Paths alone are NOT trusted for writes: match accessible mute semantics
    // and verify a transition to "Unmute microphone" after exactly one click.
    const microphone = action => {
      const controls=ctrl().filter(e=>!e.disabled&&
        e.getAttribute('aria-disabled')!=='true'&&
        !e.closest('[inert],[aria-hidden="true"]'));
      const text=e=>label(e).toLowerCase();
      const exits=voiceExits();
      const unmute=controls.filter(e=>!exits.includes(e)&&
        /(?:\bunmute\b|turn\s+on\s+(?:the\s+)?microphone|enable\s+(?:the\s+)?mic(?:rophone)?|microphone\s+(?:is\s+)?off|باز\s*کردن\s*میکروفون|روشن\s*کردن\s*میکروفون|وصل\s*میکروفون)/i.test(text(e)));
      const mute=controls.filter(e=>!exits.includes(e)&&!unmute.includes(e)&&
        /(?:\bmute\b|turn\s+off\s+(?:the\s+)?microphone|disable\s+(?:the\s+)?mic(?:rophone)?|microphone\s+(?:is\s+)?on|قطع\s*میکروفون|بستن\s*میکروفون|خاموش\s*کردن\s*میکروفون)/i.test(text(e)) &&
        !/read[ ._-]?aloud|speech|dictat|stop\s+reading|end\s+voice/i.test(text(e)));
      if(action==='inspect')return {ok:true,voiceActive:isVoice(),
        muted:unmute.length===1&&mute.length===0,
        muteReady:mute.length===1&&unmute.length===0,
        muteCount:mute.length,unmuteCount:unmute.length,
        exitCount:exits.length};
      if(action!=='mute')return {ok:false,error:'MICROPHONE_ACTION_INVALID'};
      if(unmute.length)return {ok:true,alreadyMuted:true};
      if(!mute.length)return {ok:false,error:'MIC_CONTROL_NOT_READY'};
      mute[0].click();
      return {ok:true,clicked:true};
    };

    const readAloud = action => {
      const buttons = all('button[aria-label="Read aloud"]')
        .filter(b=>!b.disabled&&b.getAttribute('aria-disabled')!=='true');
      if(action==='inspect')
        return {ok:true,ready:buttons.length>0,count:buttons.length};
      if(action==='start'){
        if(!buttons.length)
          return {ok:false,error:'READ_ALOUD_BUTTON_NOT_READY'};
        audioMonitor('arm','read-aloud');
        buttons[0].click();
        return {ok:true,clicked:true};
      }
      return {ok:false,error:'READ_ALOUD_ACTION_INVALID'};
    };

    // Active Voice Chat can accept text only if ChatGPT actually exposes an
    // editable textbox and Send. Click once without post-Send URL, identity
    // or exact user-message validation. Never fall back to Read Aloud.
    let voiceTextJob=null;
    const voiceText=(action,text) => {
      const allowedSend=()=>ctrl().filter(b=>(
        /^(send-button|voice-send-button)$/i.test(b.getAttribute('data-testid')||'')||
        /^(send|send message|send prompt|ارسال|ارسال پیام)$/i.test(
          (b.getAttribute('aria-label')||b.getAttribute('title')||'').trim())
      )&&!b.disabled&&b.getAttribute('aria-disabled')!=='true');
      if(action==='inspect'){
        const e=editor();
        return {ok:true,voiceActive:isVoice(),editorReady:!!e,
          draftEmpty:!!e&&!norm(value(e)),path:location.pathname};
      }
      if(action==='status')return voiceTextJob?
        {ok:true,stage:voiceTextJob.stage,error:voiceTextJob.error||''}:
        {ok:true,stage:'NONE'};
      if(action==='abort'){
        if(voiceTextJob?.stage==='WAITING'&&voiceTextJob.stop){
          voiceTextJob.stop();
          return {ok:true,aborted:true};
        }
        return {ok:true,aborted:false};
      }
      if(action!=='start'||typeof text!=='string'||!norm(text)||text.length>120000)
        return {ok:false,error:'INVALID_VOICE_TEXT_REQUEST'};
      if(voiceTextJob)return {ok:false,error:'VOICE_SEND_ALREADY_ATTEMPTED'};
      const job=voiceTextJob={stage:'WAITING',error:''};
      let composed=false,observer=null;
      // Audio probe remains armed from the start of Voice.
      // Mark the turn when its editor actually appears, not on a guessed timer.
      const finish=(next,error='')=>{
        if(job.stage!=='WAITING')return;
        job.stage=next;job.error=error;
        if(observer)observer.disconnect();
      };
      job.stop=()=>finish('ABORTED','ABORTED_BY_OWNER');
      const attempt=()=>{
        if(job.stage!=='WAITING')return;
        if(!composed){
          const e=editor();
          if(!e)return;
          e.focus();
          if(e.isContentEditable){
            const range=document.createRange(),sel=window.getSelection();
            range.selectNodeContents(e);range.collapse(false);
            sel.removeAllRanges();sel.addRange(range);
            document.execCommand('insertText',false,text);
          }else if(e.tagName==='TEXTAREA'){
            e.setRangeText(text,e.textLength,e.textLength,'end');
            e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));
          }
          audioMonitor('mark','voice');
          composed=true;
        }
        const buttons=allowedSend();
        if(!buttons.length)return;
        buttons[0].click();
        finish('CLICKED');
      };
      observer=new MutationObserver(attempt);
      observer.observe(document.body,{subtree:true,childList:true,attributes:true,characterData:true});
      queueMicrotask(attempt);
      return {ok:true,started:true};
    };

    window[NAME] = {revision: 'power-slider-v1652', snapshot, voice, microphone, voiceText, audioMonitor, compose, send, sendOnce, stopPendingSend, sendStatus, answer, readAloud};
    return {ok: true, installed: true};
  }

  // Page loads can replace a ChatGPT document between native eval calls.
  // A missing helper must be a structured receipt, never a JS TypeError.
  // Retry only when the helper was absent BEFORE the requested action.
  // The previous native batch protocol stores getUrl() at eval-begin and
  // requires exact equality at eval-finish. Actual ChatGPT navigation during
  // Browser 2 preparation caused SCRIPT_PAGE_CHANGED on the user's phone.
  // Existing Android v8 also exposes a single-operation 'eval' bridge which
  // evaluates one expression without that multi-bridge navigation window.
  // Use it ONLY for small, scoped agent methods; install still uses native
  // batching. Agent preconditions enforce exact URL/target/one-send.
  async function invokeInline(slot, source) {
    if (source.length > 9000) return evalBatched(slot, source, () => {}, false);
    const receipt = unpackScriptAnswer(await nativeCall('eval', {slot,script:source}));
    if (!receipt.ok) throw Error(receipt.code + ':' + receipt.text);
    if (receipt.data?.ok === false)
      throw Error(String(receipt.data.error || 'PAGE_ERROR'));
    return receipt.data;
  }
  const invokeOnce = (slot, method, ...args) => invokeInline(slot,
    '(()=>{const a=window[' + JSON.stringify(AGENT) + '];' +
    'if(!a || a.revision!=="power-slider-v1652")' +
    'return {ok:false,error:"AGENT_MISSING",path:location.pathname};' +
    'const f=a[' + JSON.stringify(method) + '];' +
    'if(typeof f!=="function")return {ok:false,error:"AGENT_METHOD_MISSING"};' +
    'return f(' + args.map(x => JSON.stringify(x)).join(',') + ');})()');
  const install = slot => evalBatched(slot,
    '(()=>{const r=(' + installBrowserAgent.toString() + ')();' +
    'const a=window[' + JSON.stringify(AGENT) + '];' +
    'return {ok:r?.ok===true && a?.revision==="power-slider-v1652" && ' +
    'typeof a.snapshot==="function",error:r?.error||"AGENT_INSTALL_UNVERIFIED",' +
    'revision:a?.revision||null,path:location.pathname};})()', () => {}, false);
  async function invoke(slot, method, ...args) {
    // Only read-only methods may be retried on a navigation race.
    // 'sendOnce', model step/open/dismiss, draft restoration and voice
    // transitions are NEVER retried after uncertain completion.
    const purelyReadOnly = method === 'snapshot' || method === 'answer' ||
      method === 'sendStatus' ||
      (method === 'microphone' && args[0] === 'inspect') ||
      (method === 'voiceText' && ['inspect','status','receipt'].includes(args[0])) ||
      (method === 'audioMonitor' && ['status','events'].includes(args[0]));
    // Read-only WebView snapshots are idempotent. A late hydration or page
    // replacement must not exhaust a hard retry budget. Wait for observable
    // page stability until the owner cancels. Mutation operations still get
    // at most one local re-install attempt and are NEVER replayed.
    for(let attempt=0;;attempt++){
      if(state.running&&state.cancelled)throw Error('CYCLE_CANCELLED');
      try{return await invokeOnce(slot,method,...args);}
      catch(error){
        const code=String(error?.message||error);
        if(purelyReadOnly&&
            /^(?:SCRIPT_PAGE_CHANGED|PAGE_CHANGED_BEFORE_EVAL)$/.test(code)){
          await sleep(0);
          continue;
        }
        if(code!=='AGENT_MISSING')throw error;
      }
      let installed;
      try{installed=await install(slot);}
      catch(error){
        if(purelyReadOnly&&String(error?.message||error)==='SCRIPT_PAGE_CHANGED'){
          await sleep(0);
          continue;
        }
        throw error;
      }
      if(installed?.ok!==true)
        throw Error('AGENT_RECOVERY_FAILED:'+String(installed?.error||'UNKNOWN'));
      try{return await invokeOnce(slot,method,...args);}
      catch(error){
        const code=String(error?.message||error);
        if(purelyReadOnly&&
            /^(?:AGENT_MISSING|SCRIPT_PAGE_CHANGED|PAGE_CHANGED_BEFORE_EVAL)$/.test(code)){
          await sleep(0);
          continue;
        }
        if(code==='AGENT_MISSING')
          throw Error('AGENT_CONTEXT_CHANGED_BEFORE_MUTATION');
        throw error;
      }
    }
  }

  function assertOk(result, code) {
    if (!result || result.ok !== true)
      throw Error(code + ':' + String(result?.error || 'NO_RECEIPT'));
    return result;
  }
  function active() {
    if (state.cancelled) throw Error('CYCLE_CANCELLED');
    if (!window.DexaHost || !hostState || hostState.count < 2)
      throw Error('TWO_BROWSERS_NOT_CONNECTED');
  }
  // Every action waits for its observed precondition/result, never for a
  // guessed response duration. Null timeout means unbounded and CANCELLABLE.
  // The short sleep below only schedules a read-only status sample; it does
  // not authorize progression, failure, retry of a Send/Delete, or cleanup.
  async function until(fn, timeout, code, delay = 0) {
    for(;;){
      active();
      const result=await fn();
      active();
      if(result)return result;
      await sleep(delay>0?delay:0);
    }
  }

  // Submit owner instructions for both WebViews. Completion, errors and
  // navigation after issuance never authorize the next action or DONE status.
  // Both WebViews receive the same shared top-header-title deletion function.
  function fireBlind(slot,label,command){
    try {
      const work=command();
      Promise.resolve(work).then(
        result=>scriptStage(slot,label,'ISSUED',undefined,state.runId),
        error=>scriptStage(slot,label+'_ERROR',
          String(error?.message||error).slice(0,80),undefined,state.runId)
      );
    }catch(error){
      scriptStage(slot,label+'_ERROR',
        String(error?.message||error).slice(0,80),undefined,state.runId);
    }
  }
  function deleteCreatedChats(){
    if(typeof window.devDeleteCurrentChat!=='function')return;
    const run=state.runId;
    for(const slot of [0,1])
      fireBlind(slot,'FINAL_DELETE',()=>window.devDeleteCurrentChat(
        slot,()=>!state.cancelled&&state.runId===run));
  }

  // One identical blind Power command sequence for Cycle and Development.
  async function setEffort(slot,target){
    active();
    if(typeof window.devSetEffortBlind!=='function')
      throw Error('BLIND_EFFORT_DISPATCH_UNAVAILABLE');
    return window.devSetEffortBlind(slot,target,()=>!state.cancelled);
  }

  // Issue one real Send and continue after the click is dispatched.
  // No URL, UUID, saved-chat or exact user-message proof is required.
  async function submit(slot, text) {
    active();
    const started=assertOk(await invoke(slot,'sendOnce',text),
      'SEND_COMMAND');
    if(!started.started)throw Error('SEND_COMMAND_NOT_STARTED');
    await until(async()=>{
      const status=assertOk(await invoke(slot,'sendStatus'),'SEND_COMMAND_STATUS');
      if(status.stage==='FAILED'||status.stage==='ABORTED')
        throw Error('SEND_COMMAND_'+String(status.error||status.stage));
      return status.stage==='CLICKED'?true:null;
    },null,'SEND_CLICK_NOT_DISPATCHED',0);
    scriptStage(slot,'CYCLE_SEND_COMMAND_CLICKED','',undefined,state.runId);
    return {clicked:true};
  }

  // A completed non-empty assistant answer, not its route or a matching
  // original user bubble, is the only response condition.
  async function waitAnswer(slot) {
    return until(async()=>{
      const v=assertOk(await invoke(slot,'answer'),'READ_ANSWER');
      if(!v.answer||v.busy||!v.completed)return null;
      const fresh=typeof window.DexaResponseCompletionState==='function'?
        window.DexaResponseCompletionState(slot):null;
      const nativeComplete=fresh?.state==='complete'&&
        fresh.signal==='ACCESSIBILITY_RESPONSE_COMPLETE'&&
        fresh.observedAt>=sendStartedAt[slot];
      return nativeComplete||v.explicitCompleted===true?v.answer:null;
    },null,'ANSWER_NOT_COMPLETE',0);
  }

  // Owner-triggered read-only diagnosis. No Send, Voice ON/OFF, microphone
  // toggle, navigation, or Delete in this path. The owner can manipulate
  // ChatGPT UI manually while the watcher reports sanitized event metadata.
  function stopManualProbe(){
    if(!manualProbeRunning)return;
    manualProbeRunning=false;
    manualProbeToken++;
    state.audioDiagnostic='پایش تشخیصی متوقف شد؛ هیچ چتی حذف نشده است.';
    try{
      scriptStage(1,'AUDIO_DIAGNOSTIC_SUMMARY',
        manualVoiceCandidateSeen?'POSSIBLE_SPEECH_END_SEEN':'NO_SPEECH_END_CANDIDATE',
        undefined,state.runId);
      scriptStage(1,'AUDIO_DIAGNOSTIC_STOPPED','',undefined,state.runId);
    }catch{}
    paint();
  }
  async function startManualProbe(){
    if(manualProbeRunning||state.running)return;
    manualProbeRunning=true;
    const token=++manualProbeToken;
    state.runId=crypto.randomUUID();
    audioTraceSeq=0;audioEventCount=0;
    audioTraceContext='';audioTraceContinuityLost=false;
    manualVoiceCandidateSeen=false;manualDiagnosticGapReported=false;
    let previousSpeechPhase='',lastTransientError='';
    const mode=state.mode==='voice'?'voice':'read-aloud';
    state.audioDiagnostic='در حال فعال‌سازی شنوندهٔ '+(mode==='voice'?'ویس چت':'بلندخوانی')+'...';
    paint();
    try{
      const armed=assertOk(await invoke(1,'audioMonitor','arm',mode),
        'MANUAL_AUDIO_PROBE_ARM');
      audioTraceContext=String(armed.pageEpoch||'?')+':'+String(armed.probeId||'?');
      scriptStage(1,'AUDIO_DIAGNOSTIC_STARTED',
        mode==='voice'?'VOICE':'READ_ALOUD',undefined,state.runId);
      while(manualProbeRunning&&token===manualProbeToken){
        if(!manualProbeRunning||token!==manualProbeToken)return;
        try{
        const r=assertOk(await invoke(1,'audioMonitor','status'),'MANUAL_AUDIO_PROBE_STATUS');
        if(r.stage==='UNARMED'){
          // WebView navigated. Re-arm observation, but do not pretend the
          // old speech trace is continuous across lost page state.
          audioTraceContinuityLost=true;
          const rearmed=assertOk(await invoke(1,'audioMonitor','arm',mode),
            'MANUAL_AUDIO_PROBE_REARM');
          audioTraceSeq=0;audioTraceContext=
            String(rearmed.pageEpoch||'?')+':'+String(rearmed.probeId||'?');
          scriptStage(1,'AUDIO_DIAGNOSTIC_REARMED_PAGE_CHANGE',
            '',undefined,state.runId);
          continue;
        }
        if(r.mode!==mode)throw Error('AUDIO_PROBE_MODE_CHANGED');
        await collectAudioTrace(true);
        if(!manualProbeRunning||token!==manualProbeToken)return;
        if(r.voiceSpeechState==='POSSIBLE_END_SPEECH')
          manualVoiceCandidateSeen=true;
        if(mode==='voice'&&r.voiceSpeechState&&
            r.voiceSpeechState!==previousSpeechPhase){
          previousSpeechPhase=r.voiceSpeechState;
          // Important signals survive the 250-event flood cap.
          scriptStage(1,'AUDIO_DIAGNOSTIC_SPEECH_PHASE',
            r.voiceSpeechState,undefined,state.runId);
        }
        const audioCount=(r.webAudioStarted||0)+(r.htmlStarted||0)+(r.speechStarted||0);
        const speechView=mode==='voice'
          ?(r.voiceSpeechState==='POSSIBLE_END_SPEECH'?
            'احتمال پایان گفتار (فقط تشخیصی)':
            r.voiceSpeechState==='SPEECH_ENERGY_DETECTED'?
            'انرژی گفتار دریافت می‌شود':
            r.voiceSpeechState==='PACKET_FLOW_STOPPED_UNKNOWN'?
            'جریان بسته‌ها قطع شده؛ نتیجه نامعلوم':
            String(r.voiceSpeechState||'در انتظار صوت'))
          :'';
        state.audioDiagnostic='پایش '+(mode==='voice'?'ویس':'بلندخوانی')+
          ': '+(mode==='voice'?speechView+'، ':'')+
          'منبع صوت '+audioCount+
          '، پایان قطعه '+(r.webAudioEnded||0)+
          '، کانال زنده '+(r.rtcLiveTracks||0)+
          '، وضعیت '+r.stage+
          '، پایان قطعی '+(r.evidence||'نامشخص');
        paint();
        lastTransientError='';
        }catch(e){
          if(!manualProbeRunning||token!==manualProbeToken)return;
          const reason=String(e?.message||e).toUpperCase()
            .replace(/[^A-Z0-9_]/g,'_').slice(0,55);
          if(reason!==lastTransientError){
            lastTransientError=reason;
            scriptStage(1,'AUDIO_DIAGNOSTIC_TEMPORARY_ERROR',
              reason,undefined,state.runId);
          }
          state.audioDiagnostic='شنونده موقتاً داده ندارد؛ منتظر بازگشت اتصال...';
          paint();
        }
        // Status probes may be delayed, but their elapsed time never
        // authorizes a Voice end or a destructive operation.
        await new Promise(resolve=>setTimeout(resolve,750));
      }
    }catch(e){
      if(manualProbeRunning&&token===manualProbeToken){
        state.audioDiagnostic='خطای پایش: '+String(e?.message||e).slice(0,90);
        scriptStage(1,'AUDIO_DIAGNOSTIC_FAILED',
          String(e?.message||e).slice(0,90),undefined,state.runId);
      }
    }finally{
      if(token===manualProbeToken){manualProbeRunning=false;paint();}
    }
  }

  // Bounded, privacy-safe diagnostic event transfer. The page reports only
  // audio event category/count; no audio samples, text or media URL.
  async function collectAudioTrace(allowDiagnosticGap=false) {
    const stream=assertOk(await invoke(1,'audioMonitor','events',audioTraceSeq),
      'AUDIO_TRACE_READ');
    if(stream.stage==='UNARMED')throw Error('AUDIO_PROBE_CONTEXT_LOST');
    const context=String(stream.pageEpoch||'?')+':'+String(stream.probeId||'?');
    if(audioTraceContext&&audioTraceContext!==context){
      audioTraceContinuityLost=true;
      audioTraceSeq=0;
      audioTraceContext=context;
      scriptStage(1,'CYCLE_AUDIO_DOCUMENT_REPLACED','',undefined,state.runId);
      // No audio event can be invented for the period of a page change.
      return stream;
    }
    if(!audioTraceContext)audioTraceContext=context;
    if(stream.lost){
      audioTraceContinuityLost=true;
      if(!allowDiagnosticGap)throw Error('AUDIO_EVENT_HISTORY_GAP');
      // Manual diagnosis is non-destructive and may continue after a burst
      // of events. Explicitly disclose the gap and resync. This data cannot
      // subsequently be used as a completion certificate.
      if(!manualDiagnosticGapReported){
        manualDiagnosticGapReported=true;
        scriptStage(1,'AUDIO_DIAGNOSTIC_TRACE_GAP','',
          undefined,state.runId);
      }
      audioTraceSeq=stream.seq;
      return stream;
    }
    for(const event of stream.events||[]){
      if(!Number.isSafeInteger(event.seq)||event.seq<=audioTraceSeq)continue;
      audioTraceSeq=event.seq;
      if(audioEventCount<250 &&
          /^[A-Z][A-Z0-9_]{2,45}$/.test(event.code||'')){
        audioEventCount++;
        scriptStage(1,'CYCLE_AUDIO_'+event.code,'',
          Number.isInteger(event.count)?event.count:undefined,state.runId);
        if(audioEventCount===250)
          scriptStage(1,'CYCLE_AUDIO_TELEMETRY_CAPPED','',undefined,state.runId);
      }
    }
    // Keep observing audio counters and completion even after telemetry is
    // capped. High-frequency speech must not stop a legitimate cycle.
    return stream;
  }

  // The passive audio observer runs concurrently with the FULL cycle.
  // It never waits for proof of the Voice text message, never clicks ChatGPT,
  // never interprets silence as completion, and never authorizes deletion.
  // This is how owner test telemetry survives the old stuck receipt stage.
  function startCycleAudioDiagnostics(mode,baseline){
    if(cycleAudioPumpRunning)return;
    cycleAudioPumpRunning=true;
    const token=++cycleAudioPumpToken;
    cycleAudioPumpMode=mode;cycleAudioLastSnapshot='';
    cycleAudioLastError='';cycleAudioSnapshotCount=0;
    cycleAudioNativeComplete=false;
    audioTraceSeq=0;audioEventCount=0;
    audioTraceContinuityLost=false;
    audioTraceContext=baseline?.pageEpoch&&baseline?.probeId?
      baseline.pageEpoch+':'+baseline.probeId:'';
    scriptStage(1,'CYCLE_AUDIO_BACKGROUND_STARTED',
      mode==='voice'?'VOICE':'READ_ALOUD',undefined,state.runId);
    void (async()=>{
      while(cycleAudioPumpRunning&&token===cycleAudioPumpToken&&!state.cancelled){
        try{
          const check=assertOk(await invoke(1,'audioMonitor','status'),
            'AUDIO_BACKGROUND_STATUS');
          if(check.stage==='UNARMED'){
            audioTraceContinuityLost=true;
            scriptStage(1,'CYCLE_AUDIO_UNARMED_AFTER_NAV','',undefined,state.runId);
            const armed=assertOk(await invoke(1,'audioMonitor','arm',mode),
              'AUDIO_BACKGROUND_REARM');
            audioTraceSeq=0;
            audioTraceContext=armed.pageEpoch+':'+armed.probeId;
            scriptStage(1,'CYCLE_AUDIO_REARMED_AFTER_NAV','',undefined,state.runId);
          }else{
            await collectAudioTrace();
            // Only semantic flags and bounded counter buckets, never a URL,
            // conversation identifier, prompt, text or audio bytes.
            const report=[
              'V'+Number(!!check.voiceActive),
              'S'+Number(!!check.voiceSpoke),
              'L'+Number(!!check.voiceListeningAfterSpeech),
              'X'+Number(!!check.voiceExitVisible),
              'M'+Number(!!check.voiceMicMutedVisible),
              'R'+Math.min(9,check.rtcPeers||0),
              'T'+Math.min(9,check.rtcLiveTracks||0),
              'H'+Math.min(9,check.htmlStarted||0),
              'P'+Math.min(9,check.htmlPaused||0),
              'E'+Math.min(9,check.htmlEnded||0),
              'W'+Math.min(9,Math.floor((check.webAudioStarted||0)/25)),
              'F'+String(check.rtcObservation||'UNKNOWN').slice(0,30)
            ].join('_');
            if(report!==cycleAudioLastSnapshot&&cycleAudioSnapshotCount<90){
              cycleAudioLastSnapshot=report;
              cycleAudioSnapshotCount++;
              scriptStage(1,'CYCLE_AUDIO_PASSIVE_SNAPSHOT',report,
                undefined,state.runId);
            }
            const fresh=typeof window.DexaResponseCompletionState==='function'?
              window.DexaResponseCompletionState(1):null;
            if(!cycleAudioNativeComplete&&mode==='voice'&&
               sendStartedAt[1]>0&&fresh?.state==='complete'&&
               fresh.signal==='ACCESSIBILITY_RESPONSE_COMPLETE'&&
               fresh.observedAt>=sendStartedAt[1]){
              cycleAudioNativeComplete=true;
              scriptStage(1,'CYCLE_VOICE_NATIVE_TEXT_DONE',
                check.evidence?'AUDIO_CONFIRMED':'AUDIO_NOT_CONFIRMED',
                undefined,state.runId);
            }
            const summary=(mode==='voice'?'ویس':'بلندخوانی')+
              ': نشست '+(check.voiceActive?'فعال':'غیرفعال')+
              (mode==='voice'?'، گفتار '+String(check.voiceSpeechState||'نامعلوم'):'')+
              '، منابع صوتی '+((check.webAudioStarted||0)+(check.htmlStarted||0))+
              '، پایان قطعه '+(check.webAudioEnded||0)+
              '، کانال زنده '+(check.rtcLiveTracks||0)+
              '، مشاهدهٔ شبکه '+String(check.rtcObservation||'نامعلوم')+
              '، پایان گفتار '+(check.evidence?'دارای شاهد':'نامشخص');
            if(state.audioDiagnostic!==summary){
              state.audioDiagnostic=summary;paint();
            }
            cycleAudioLastError='';
          }
        }catch(e){
          const message=String(e?.message||e);
          const reason=message.toUpperCase().replace(/[^A-Z0-9_]/g,'_').slice(0,75);
          if(reason!==cycleAudioLastError){
            cycleAudioLastError=reason;
            scriptStage(1,'CYCLE_AUDIO_PASSIVE_ERROR',reason,undefined,state.runId);
          }
        }
        if(!cycleAudioPumpRunning||token!==cycleAudioPumpToken)break;
        await sleep(500); // read-only observation cadence; NEVER a completion timer
      }
    })().catch(()=>{});
  }
  async function stopCycleAudioDiagnostics(){
    if(!cycleAudioPumpRunning)return;
    cycleAudioPumpRunning=false;cycleAudioPumpToken++;
    try{await collectAudioTrace();}catch{}
    scriptStage(1,'CYCLE_AUDIO_BACKGROUND_STOPPED',
      audioTraceContinuityLost?'CONTEXT_GAP':'TRACE_CLOSED',
      undefined,state.runId);
  }

  // Voice can temporarily live at /c/local-chatgpt while genuine native
  // speech and one exact user message already exist. That ephemeral path is
  // NOT an owned canonical conversation. Do not replay Send or pretend UUID.
  // One real Voice Send click only, no post-Send UUID or exact bubble check.
  async function sendToActiveVoice(slot,text) {
    const started=assertOk(await invoke(slot,'voiceText','start',text),'VOICE_TEXT_START');
    if(!started.started)throw Error('VOICE_TEXT_NOT_STARTED');
    await until(async()=>{
      const status=assertOk(await invoke(slot,'voiceText','status'),
        'VOICE_SEND_COMMAND_STATUS');
      if(status.stage==='FAILED'||status.stage==='ABORTED')
        throw Error('VOICE_SEND_'+String(status.error||status.stage));
      return status.stage==='CLICKED'?true:null;
    },null,'VOICE_SEND_CLICK_NOT_DISPATCHED',0);
    scriptStage(slot,'CYCLE_VOICE_SEND_COMMAND_CLICKED','',undefined,state.runId);
    return {clicked:true};
  }

  // A paused stream, a single buffer chunk ending, a silent open WebRTC
  // channel and a fresh textual-completion signal alone cannot authorize
  // ending Voice or deleting chats. Require an independent audio/UI witness.
  async function awaitAudioEnd(mode) {
    const expected=mode==='voice'?'voice':'read-aloud';
    const result=await until(async()=>{
      if(audioTraceContinuityLost)throw Error('AUDIO_PROBE_DOCUMENT_GAP');
      await collectAudioTrace();
      const r=assertOk(await invoke(1,'audioMonitor','status'),'AUDIO_STATUS');
      if(r.mode!==expected||r.stage==='UNARMED')
        throw Error('AUDIO_PROBE_CONTEXT_LOST');
      if(r.stage==='AMBIGUOUS')throw Error('AUDIO_SOURCE_OR_INTERRUPTION_AMBIGUOUS');
      const activity=[r.webAudioStarted||0,r.htmlStarted||0,r.speechStarted||0];
      state.audioDiagnostic='پایش صوت: قطعهٔ وب‌آدیو '+activity[0]+
        '، صوت معمولی '+activity[1]+'، گفتار دستگاه '+activity[2]+
        '، پایان قطعه '+(r.webAudioEnded||0)+
        '، کانال صوتی قابل‌مشاهده '+(r.rtcLiveTracks||0)+
        '، نشانهٔ پایان '+(r.evidence?'دریافت شد':'نامشخص');
      paint();
      if(r.stage!=='ENDED'||!r.started||!r.evidence)return null;
      if(expected==='read-aloud'&&
          ['HTML_MEDIA_NATURAL_ENDED_AND_PLAYER_READY',
           'HTML_MEDIA_ENDED_STATE_AND_PLAYER_READY',
           'SPEECH_SYNTHESIS_ENDED_AND_PLAYER_READY',
           'WEB_AUDIO_CHUNKS_ENDED_AND_PLAYER_READY'].includes(r.evidence))
        return r;
      if(expected==='voice'&&r.voiceActive&&
          ['VOICE_SPEAKING_TO_LISTENING_WITH_AUDIO_END',
           'VOICE_NATURAL_SEGMENTS_AND_QUIET_RTP'].includes(r.evidence))
        return r;
      return null;
    },null,mode==='voice'?'VOICE_SPEECH_TURN_END_NOT_PROVEN':
      'READ_ALOUD_END_NOT_PROVEN',420);
    // Only actual natural audio-end evidence authorizes Voice OFF.
    // Text, mic-state and UUID rechecks are not part of that decision.
    scriptStage(1,'CYCLE_AUDIO_COMPLETION_'+result.evidence,'',undefined,state.runId);
    return result;
  }

  async function run() {
    if(state.running)return;
    if(manualProbeRunning)stopManualProbe();
    state.output='';state.firstQuestion='';state.validation='';
    state.error='';state.runId=crypto.randomUUID();
    state.audioDiagnostic='شنوندهٔ صوتی: آمادهٔ ثبت رویدادها';
    audioTraceSeq=0;audioEventCount=0;
    audioTraceContext='';audioTraceContinuityLost=false;
    sendStartedAt.fill(0);
    const settings={prompt:state.prompt.trim(),first:state.first,
      second:state.second,mode:state.mode,readAloud:state.readAloud,
      wrapper:state.wrapper};
    if(!settings.prompt){
      stage('INPUT_REQUIRED','ابتدا پیام مرورگر اول را بنویس.');return;
    }
    if(!hostState||hostState.count<2||!window.DexaHost){
      stage('HOST_REQUIRED','داشبورد باید به دو مرورگر اندروید متصل باشد.');return;
    }
    state.running=true;state.cancelled=false;
    try{
      // Stop the retired handoff best-effort; never query its state or gate.
      try{window.DexaAutoHandoff?.stop?.()}catch(_){}
      const run=state.runId;
      stage('DELETE_CURRENT_CHATS','صدور فوری فرمان حذف برای هر دو مرورگر...');
      if(typeof window.devDeleteCurrentChat==='function')
        for(const slot of [0,1])
          fireBlind(slot,'INITIAL_DELETE',()=>window.devDeleteCurrentChat(
            slot,()=>!state.cancelled&&state.runId===run));
      stage('CLEAR_BOTH_DRAFTS','صدور فوری فرمان پاک‌کردن پیش‌نویس هر دو مرورگر...');
      if(typeof window.devTask6Invoke==='function')
        for(const slot of [0,1])
          fireBlind(slot,'INITIAL_CLEAR',()=>window.devTask6Invoke(slot,'clear'));
      stage('SET_BOTH_EFFORTS','صدور فرمان تنظیم ایفورت هر دو مرورگر...');
      // Key sequences must finish dispatching before Voice / Send; results
      // do not gate subsequent commands or require any value readback.
      await Promise.allSettled([setEffort(0,settings.first),setEffort(1,settings.second)]);
      active();

      // After effort command dispatch, enter Voice and issue one mic Mute.
      // No before/after mic state readback is required to start Send.
      if(settings.mode==='voice'){
        stage('VOICE_START','مرورگر دوم: فعال‌سازی چت صوتی واقعی...',1);
        const audioArm=assertOk(await invoke(1,'audioMonitor','arm','voice'),
          'VOICE_AUDIO_PROBE_ARM');
        startCycleAudioDiagnostics('voice',audioArm);
        if(typeof window.devVoiceInvoke!=='function')
          throw Error('DEV_VOICE_CONTROL_UNAVAILABLE');
        // Readiness can lag effort-menu close. A missing Voice entry has
        // performed NO click, so observing the same proven native entry
        // again is safe; never retry an ambiguous or already-clicked action.
        const switched=await until(async()=>{
          try{
            const r=await window.devVoiceInvoke(1,true);
            if(!r?.dispatched&&!r?.already)throw Error('VOICE_ON_NOT_DISPATCHED');
            return r;
          }catch(e){
            if(String(e?.message||e)==='VOICE_ENTRY_NOT_UNIQUE_0')return null;
            throw e;
          }
        },null,'VOICE_ENTRY_NOT_RENDERED_AFTER_EFFORT',0);
        stage('VOICE_MIC_COMMAND','مرورگر دوم: صدور یک فرمان قطع میکروفون...',1);
        // Readiness is observed by the one actual Mute action only. No
        // inspection of mic state before or after dispatch.
        await until(async()=>{
          try{
            const v=await invoke(1,'microphone','mute');
            return v?.clicked||v?.alreadyMuted?true:null;
          }catch(e){
            const code=String(e?.message||e);
            if(code.includes('MIC_CONTROL_NOT_READY'))
              return null; // The Mute button has not been clicked yet.
            throw e;
          }
        },null,'VOICE_MUTE_CONTROL_NOT_READY',0);
      }

      stage('FIRST_SEND','مرورگر اول: ارسال پیام اولیه...',0);
      sendStartedAt[0]=Date.now();
      await submit(0,settings.prompt);
      stage('FIRST_REPLY','مرورگر اول: منتظر پایان واقعی پاسخ...',0);
      const firstAnswer=await waitAnswer(0);
      state.firstQuestion=firstAnswer;paint();
      const wrapped=(settings.wrapper.trim()?
        settings.wrapper.trim()+'\n\n':'')+firstAnswer;

      stage('SECOND_SEND','مرورگر دوم: ارسال متن رپر و پاسخ واقعی...',1);
      sendStartedAt[1]=Date.now();
      if(settings.mode==='voice')await sendToActiveVoice(1,wrapped);
      else await submit(1,wrapped);
      stage('SECOND_REPLY','مرورگر دوم: منتظر پایان پاسخ واقعی...',1);
      const finalAnswer=await waitAnswer(1);
      state.output=finalAnswer;state.validation='';paint();

      if(settings.mode==='text'&&settings.readAloud){
        stage('READ_ALOUD_START','شروع بلندخوانی پاسخ نهایی در مرورگر دوم...',1);
        await until(async()=>{
          const a=assertOk(await invoke(1,'readAloud','inspect'),'READ_ALOUD_BUTTON');
          return a.ready?true:null;
        },null,'READ_ALOUD_CONTROL_NOT_READY',0);
        audioTraceSeq=0;
        await invoke(1,'readAloud','start');
        // Read Aloud already armed the same page agent; stream diagnostic
        // immediately without changing the real user's playback controls.
        const begun=assertOk(await invoke(1,'audioMonitor','status'),
          'READ_ALOUD_PROBE_INITIAL_STATUS');
        startCycleAudioDiagnostics('read-aloud',begun);
        stage('READ_ALOUD_WAIT','منتظر پایان طبیعی فایل و آماده‌شدن دوبارهٔ پخش‌کننده...',1);
        await awaitAudioEnd('read-aloud');
      }else if(settings.mode==='voice'){
        stage('VOICE_WAIT_SPEECH_END','منتظر پایان قطعی پاسخ صوتی؛ سکوت موقت کافی نیست.',1);
        await awaitAudioEnd('voice');
        stage('VOICE_STOP','پایان مکالمهٔ صوتی پس از اتمام پاسخ...',1);
        // Command once after true audio completion, no repeat proof readback.
        await window.devVoiceInvoke(1,false);
      }
      active();

      stage('END_CLEANUP','پایان پاسخ تأیید شد؛ حذف دو گفت‌وگوی ساخته‌شده...',1);
      deleteCreatedChats();
      stage('DONE','چرخه کامل شد؛ فرمان حذف هر دو مرورگر صادر شد.',1);
    }catch(e){
      const code=String(e?.message||e);
      stage('FAILED','چرخه متوقف شد؛ یک فرمان یا مرحله اجرا نشد.',
        0,code.slice(0,140));
    }finally{
      await stopCycleAudioDiagnostics();
      state.running=false;paint();
    }
  }

  window.DexaCycle = {mount, read: () => ({
    stage: state.stage, running: state.running, error: state.error,
    mode: state.mode, readAloud: state.readAloud,
    audioDiagnostic: state.audioDiagnostic,
    outputLength: state.output.length, questionLength: state.firstQuestion.length,
    validation: state.validation, runId: state.runId
  })};
  if (typeof selectedBoard !== 'undefined' && selectedBoard === 'cycle') mount();
})();