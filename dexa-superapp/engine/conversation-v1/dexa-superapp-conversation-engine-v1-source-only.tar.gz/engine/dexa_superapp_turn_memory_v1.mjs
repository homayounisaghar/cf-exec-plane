// Dexa Superapp conversational-turn history, intentionally separate from Rana
// execution success, receipts, and any legacy mission follow-up state.
const RESPONDED_STATES=new Set([
 'SUCCEEDED_VERIFIED','BLOCKED','FAILED','OUTCOME_UNKNOWN','STOPPED_FUTURE',
 'CONVERSATION_TURN_COMPLETED',
 'WAITING_USER_DECISION','WAITING_USER_AUTH','WAITING_EXTERNAL','PAUSED'
]);
const DEFAULT_LIMIT=30;
const MAX_LIMIT=100;

export function readSuperappHistoryLimit(env=process.env){
 const raw=env.DEXA_SUPERAPP_HISTORY_LIMIT;
 if(raw===undefined||raw==='')return DEFAULT_LIMIT;
 if(typeof raw!=='string'||!/^[1-9][0-9]{0,2}$/.test(raw)||
   Number(raw)>MAX_LIMIT)
  throw Error('DEXA_SUPERAPP_HISTORY_LIMIT_INVALID');
 return Number(raw);
}

export function superappTurnReply(m,formattedReply=null){
 if(!m||m.source!=='dexa_superapp'||!RESPONDED_STATES.has(m.state)||
   typeof m.text!=='string'||!m.text.trim())return null;
 const text=typeof m.displayedReplyExact==='string'&&m.displayedReplyExact.trim()?
   m.displayedReplyExact:
   typeof formattedReply==='string'&&formattedReply.trim()?
     formattedReply:m.outcome?.result;
 return typeof text==='string'&&text.trim()?text:null;
}

export function superappConversationHistory(missions,{limit=DEFAULT_LIMIT,
 displayReply=()=>null}={}){
 if(!Number.isSafeInteger(limit)||limit<1||limit>MAX_LIMIT)
  throw Error('DEXA_SUPERAPP_HISTORY_LIMIT_INVALID');
 const rows=[];
 for(const m of missions){
  const reply=superappTurnReply(m,displayReply(m));
  if(reply===null)continue;
  rows.push({createdAt:m.createdAt||null,user:m.text,assistant:reply,
   executionState:m.state,turnComplete:true,
   effectsExecuted:Number.isSafeInteger(m.outcome?.proof?.effectsExecuted)&&
     m.outcome.proof.effectsExecuted>=0?m.outcome.proof.effectsExecuted:null,
   id:m.id});
 }
 rows.sort((a,b)=>String(a.createdAt||'').localeCompare(String(b.createdAt||''))||
   String(a.id||'').localeCompare(String(b.id||'')));
 return rows.slice(-limit).map(({id,...row})=>row);
}

export const DEXA_SUPERAPP_HISTORY_MAX=MAX_LIMIT;
